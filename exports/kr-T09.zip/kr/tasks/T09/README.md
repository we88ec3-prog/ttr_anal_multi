# T09 關卡內移動與同步

狀態：review-ready-partial；負責人：未認領。

## 目標與邊界

共用 actor 移動、位置旗標、碰撞邊界及校正；不制定決策

排除：不重新實作遊戲規則、不執行目標；其他任務的核心函式僅引用

## 已有成果與未知

詳 task.json 及查詢工具的 claims/corrections。

- 原生命令產生權責、碰撞細節及校正來源仍未知

## 共用依賴

T02, T04, T06, T08。依賴任務只帶介面及直接證據，不遞迴擴展整張圖。

## 下一步與驗收

- 先查來源與更正，再選一個具體阻塞；認領主要函式後開工。
- 僅對缺口做後續定向核對；缺少後端規則需標記待補充開發。
- 列明每項原生/部分/AI替代/缺失/待開發狀態與證據
- 交付已查範圍、缺口和遊玩影響，不以候選數或偽碼量驗收

## 必要來源

- [ACTOR-TARGET-POSITION-SOURCE.md](../../../kr/evidence/4409808e43eabea02d3d18aac8e9fa705932c84faf01079a96239fcb12f41ae7.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [NATIVE-MOVEMENT-CONSUMER.md](../../../kr/evidence/ee36565a40d1ec7a15040a57ce40ca9179b9a216fc3331fd058bfa73d094bcc6.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [POSITION-UPDATE-AND-MOVEMENT-WRITERS.md](../../../kr/evidence/00d7c1b55f3b4514fdf9db13874bc6008a563ca3e7d7d116036029327c83617e.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [SCRIPT-OBJECT-MOTION-BOUNDARY.md](../../../kr/evidence/3db1e759b68fb22ca16a0b268f557a2dba2d00cd4f73ebdaaf76f33a40da49a2.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [audit_actor_target_producers.py](../../../unclassified/evidence/ccf2df7e156674571ff3abb7a0d1ab697f5e0876d4e36955735212377ffe20e7.txt) — No exact target binding established; source retained for review
- [audit_native_movement_consumer.py](../../../unclassified/evidence/c6a4f37c88fee8cf75fb0391df9fb84fad71bb8aedfcda967c13507929547987.txt) — No exact target binding established; source retained for review
- [audit_position_update_and_reset.py](../../../kr/evidence/f627faa95117be14eccf61fa1b6fdd99a78b2372af8ca73dfd413db6dfcfc285.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [audit_script_object_motion.py](../../../kr/evidence/3784075d4a7148da5007f07f7a40abcc64a75f4f949b0ea1fa56e692d968fdc6.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [kr-frame-dispatch-20261023/corrections.json](../../../unclassified/evidence/815b706183d0c9944787c7243a07dee6a1332685ea248692513d3c98aae622c2.txt) — No exact target binding established; source retained for review
- [kr-frame-dispatch-20261023/frame-paths.json](../../../kr/evidence/65f0c8ca3d39abf67d181959bbae931273a75d2f28083227e02275ad92452bb9.txt) — Contains exact KR hash; assertion scope still bounded by record
- [kr-frame-dispatch-20261023/identity.json](../../../kr/evidence/2d9fc381a82a8f0d93ad2b4bca23c6c9c5e31ab4556c81d14b5181bc794da9d2.txt) — Contains exact KR hash; assertion scope still bounded by record
- [movement_position.py](../../../kr/evidence/846599cf8a88e9b999e75bc4f8bbfcd4930f2a8e31c0e2de5b30b6df3a07c40f.txt) — Curated association with KR local test implementation; NOT original-binary evidence
- [native-index/actor-battle-stop-receive.txt](../../../unclassified/evidence/b89fc23b400e24121147a707f1e522351e9b00fafebb4fdb03765c3bc64fb876.txt) — No exact target binding established; source retained for review
- [native-index/actor-input-phase-common.txt](../../../unclassified/evidence/b2ec3394f651ee67be9569e08397d9eab7cb09f4fbdb012230997042cd91ae44.txt) — No exact target binding established; source retained for review
- [native-index/actor-input-phase.txt](../../../unclassified/evidence/19ac9d151365da67b763ed9f86ced86a69c918f793bd9ca5b96413e8977e4db2.txt) — No exact target binding established; source retained for review
- [native-index/actor-input-tree-walk.txt](../../../unclassified/evidence/4e3d32f6a54a8c08c25a5b93e01b3fb99fb7aeb6ec3702d8cd3172a23a9e9d83.txt) — No exact target binding established; source retained for review
- [native-index/actor-residual-position-correction.txt](../../../unclassified/evidence/f6759f0379a93f1cb6fe093b3fb45f8b703470eb2d1876f9e40fbc5aed25fe66.txt) — No exact target binding established; source retained for review
- [native-index/actor-target-position-receive.txt](../../../unclassified/evidence/2cf70c84f011058dafcddf8fe7c503be448995098cc585b72eedf743fffc19a2.txt) — No exact target binding established; source retained for review
- [native-index/actor-target-producer-audit.json](../../../kr/evidence/91d22e4e9e1328e9cbfaef10327808228daa99d702514cc7c30f1706d1496f41.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/movement-field-writer-candidates.json](../../../kr/evidence/e6fbd954ea76ae6568a4bcfb6467a7b9bf8bb997bff8b23d013f7eaf37bd4784.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/native-heading-smoothing.txt](../../../unclassified/evidence/30c483947738a3772dc8702172172c6aeae05093c1dde13a447d83c68cc6a770.txt) — No exact target binding established; source retained for review
- [native-index/native-movement-consumer-audit.json](../../../kr/evidence/a232a9412df8ad8943bb5c4b19d9235e70e321db5abcddf7a934cc09fec7503d.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/native-movement-consumer.txt](../../../unclassified/evidence/6eb36f58ca42dd0126191c4b6adf41d807b045eb90a50fb25ff8a39ae4e79c60.txt) — No exact target binding established; source retained for review
- [native-index/native-movement-relative-position.txt](../../../unclassified/evidence/8551b90f0bcd479521c1d3931bfd11ade630fe9fbe0a680a7aae4895830fb492.txt) — No exact target binding established; source retained for review
- [native-index/monster-effective-speed.txt](../../../unclassified/evidence/4bda15af5f27661338975b7109162a76cd993f28f2aa4d70288ae3f19277f1fe.txt) — No exact target binding established; source retained for review
- [native-index/position-update-reset-audit.json](../../../kr/evidence/d60a7dc687112ab05b1d4790bcf57b0cc496de65d9396f8ab509a188d4e836bb.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/script-object-motion-audit.json](../../../kr/evidence/5cc77faebee10f1aaf3c439545976a771918ad68b31191e05ae1f7f21d9aa9db.txt) — Contains exact KR hash; assertion scope still bounded by record
- [scan_movement_field_writers.py](../../../unclassified/evidence/9de397913910e99b5d24ba9d13430ad62902fda225a3c2994f5d0cdad3ae3ad3.txt) — No exact target binding established; source retained for review
- [tutorial_monster_ai.py](../../../kr/evidence/9c1a55a267f465549b585b7c457471a6ce293feac0fe57daf40f3b74f6669286.txt) — Curated association with KR local test implementation; NOT original-binary evidence
- [MAIN-PROGRAM-FUNCTION-MAP.md](../../../kr/evidence/546a89f51d0c1dc55b81c98bb0c29c632bc445a40c08d63b237a01793475f68f.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [NATIVE-BEHAVIOR-MAP.md](../../../unclassified/evidence/b4eb2f9eb1476821ad1b910bb7f8ba8914842b67b31bb418cc147dbee42f5c18.txt) — No exact target binding established; source retained for review
- [kr-boundaries-20261022/boundary-records.json](../../../kr/evidence/223d788262cf02fb04f968e8bf29c1dbd30296b201377a985df2d2ed1831f732.txt) — Contains exact KR hash; assertion scope still bounded by record
- [kr-boundaries-20261022/slot-dispositions.json](../../../kr/evidence/6c8fd87928aa3390c8a2e73f1490698771236bfcceefd785172c752e7f30e69c.txt) — Contains exact KR hash; assertion scope still bounded by record
- [kr-unified-ledger-20261023/catalog.json](../../../kr/evidence/eaa97822197f2d699c3234ff07947f90a04ee71bf03f9c5fc188e49b15a77cf4.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/method-atlas/summary.json](../../../kr/evidence/b5621564b75a6eecf3eb300f16261099ff4972c72b2b490607544925c112da3a.txt) — Contains exact KR hash; assertion scope still bounded by record
