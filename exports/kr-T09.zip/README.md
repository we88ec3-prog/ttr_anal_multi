# KR T09 獨立交接包

入口：[關卡內移動與同步](kr/tasks/T09/README.md)。

狀態：review-ready-partial。只讀審核現有證據；不代表功能完成。

```powershell
python shared/handoff.py verify
python shared/handoff.py query --version kr --task T09
```

原始程式另行供應並核對 shared/targets.json 的SHA。閱讀與校驗不需要原anal目錄。Python 3.10+，標準函式庫即可；繼續原生分析才需要REA/Ghidra。

證據檔為原始內容的惰性.txt副本；其舊絕對路徑只作出處。直接依賴任務帶入介面資料，不表示其所有外部需求均已解決。不可執行打包的舊腳本。
