# T08 實體生成與移除

狀態：review-ready-partial；負責人：未認領。

## 目標與邊界

0007 建立、登記、移除的資料介面；不制定生成時間或決策規則

排除：不重新實作遊戲規則、不執行目標；其他任務的核心函式僅引用

## 已有成果與未知

詳 task.json 及查詢工具的 claims/corrections。

- 數量、座標、時機、owner 正式來源及通用移除規則缺失

## 共用依賴

T02, T06, T07。依賴任務只帶介面及直接證據，不遞迴擴展整張圖。

## 下一步與驗收

- 先查來源與更正，再選一個具體阻塞；認領主要函式後開工。
- 僅對缺口做後續定向核對；缺少後端規則需標記待補充開發。
- 列明每項原生/部分/AI替代/缺失/待開發狀態與證據
- 交付已查範圍、缺口和遊玩影響，不以候選數或偽碼量驗收

## 必要來源

- [LB-CREATE-OBJECT-ABI-AND-CONTROL.md](../../../kr/evidence/33de7cea0ce88d82032b9b4e5fe7689a8acb8e4ef15728d78ba0b96c1e033ec5.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [MONSTER-SPAWN-AND-CONTROL-BOUNDARY.md](../../../unclassified/evidence/6ef16f451f942d2e828a1b6936b466332736d7dc75fa0152fcbb6289863902dd.txt) — No exact target binding established; source retained for review
- [SCRIPT-OBJECT-CREATION-AND-OWNERSHIP.md](../../../kr/evidence/b9e06b547ba8028e9a2383caa9c1ad6082e03a02897b554ce222df272e772b20.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [audit_lb_create_object_abi.py](../../../kr/evidence/4fa0939b7e927480bff5617c84c042b2878c8c4f307d82985b78d2095f88119a.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [audit_monster_spawn_control.py](../../../unclassified/evidence/fe843f6e9d6a23bad7405d0daf0e4eddaa043b0571b1d8c3fcf82c8ce38df2ae.txt) — No exact target binding established; source retained for review
- [audit_script_object_lifecycle.py](../../../kr/evidence/fb396ef585cf77e9ebfe3b2e7efcba45ecef1a48a3980e4a0717dec046872a27.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [native-index/actor-control-assignment-bounded.txt](../../../unclassified/evidence/edad70db3c441b0936b7f9090776679d5eefc4a3e508cc8b7cd8d1a2c184a210.txt) — No exact target binding established; source retained for review
- [native-index/common-actor-map-registration.txt](../../../unclassified/evidence/2b03641dba4cc73a8ecf0fdceb9135b3ba987dceb2a652aaedd953c48ef675b4.txt) — No exact target binding established; source retained for review
- [native-index/lb-create-object-abi-audit.json](../../../kr/evidence/117948deb154e54a66f233d059f7385cd0c9da84f3059991f764bae3993ee168.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/lb-script-references.json](../../../unclassified/evidence/37bee438ee50f3dee2e82f8e3f94ba29c2675401cc492a56e064aa2b6e0e9214.txt) — No exact target binding established; source retained for review
- [native-index/monster-spawn-common-receiver.txt](../../../unclassified/evidence/232b1e969052328119dd37ad9b3487eb7aff2f9437a29ea1ade63e01e8b2c0ae.txt) — No exact target binding established; source retained for review
- [native-index/monster-spawn-control-audit.json](../../../kr/evidence/9f023435f85886c849e3a0266f00700d294b6a2625ccd11a777512934a11b449.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/player-active-actor-helper.txt](../../../unclassified/evidence/60f331c6c4569ada50b572bc1231a90efbe6ebdea4642139ef608bfb8cd80e94.txt) — No exact target binding established; source retained for review
- [native-index/script-object-lifecycle-audit.json](../../../kr/evidence/c21e09019d3e7e97fddc6f8ff8b334aa849964cd7eba41662f3fec5e6f0c9d56.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/spawn-auxiliary-marker-free.txt](../../../unclassified/evidence/9f6ecdc49a5e76927c9291ffd351a9968d54c0baf9edba5439013599f8fc4842.txt) — No exact target binding established; source retained for review
- [native-index/spawn-auxiliary-marker-insertion.txt](../../../unclassified/evidence/058b32976b87013fa975500b5fe126d574963ad3b3e03c95a5a43fe7727f233f.txt) — No exact target binding established; source retained for review
- [native-index/spawn-auxiliary-marker-manager-constructor.txt](../../../unclassified/evidence/83e988ac6b0f02987d703927bf132cbd0ee9bea5d166bca2de3dac58618dab69.txt) — No exact target binding established; source retained for review
- [native-index/spawn-auxiliary-marker-render.txt](../../../unclassified/evidence/ad554ad1d134f6e8f9351a02538a9b011174849a673f024e1e1ca25bf72046b1.txt) — No exact target binding established; source retained for review
- [scan_lb_script_references.py](../../../unclassified/evidence/8876fa300f1c610f1f331c6cc554f11d8a1132eac240c97d3ccaaff33673214d.txt) — No exact target binding established; source retained for review
- [tutorial_battle.py](../../../kr/evidence/d642bd503a2ec2ac4b58fb569bbb77901fba2d37246a8421eac9c8c266f96d28.txt) — Curated association with KR local test implementation; NOT original-binary evidence
- [tutorial_monster_config.py](../../../kr/evidence/11ec8d8e1e642d2626727bab0c397e16a0ad1c7b9556fa2d0b3e0121bd0ce9d8.txt) — Curated association with KR local test implementation; NOT original-binary evidence
- [MAIN-PROGRAM-FUNCTION-MAP.md](../../../kr/evidence/546a89f51d0c1dc55b81c98bb0c29c632bc445a40c08d63b237a01793475f68f.txt) — Explicit historical original-KR attribution; exact hash requires linked audit
- [NATIVE-BEHAVIOR-MAP.md](../../../unclassified/evidence/b4eb2f9eb1476821ad1b910bb7f8ba8914842b67b31bb418cc147dbee42f5c18.txt) — No exact target binding established; source retained for review
- [kr-boundaries-20261022/boundary-records.json](../../../kr/evidence/223d788262cf02fb04f968e8bf29c1dbd30296b201377a985df2d2ed1831f732.txt) — Contains exact KR hash; assertion scope still bounded by record
- [kr-boundaries-20261022/slot-dispositions.json](../../../kr/evidence/6c8fd87928aa3390c8a2e73f1490698771236bfcceefd785172c752e7f30e69c.txt) — Contains exact KR hash; assertion scope still bounded by record
- [kr-unified-ledger-20261023/catalog.json](../../../kr/evidence/eaa97822197f2d699c3234ff07947f90a04ee71bf03f9c5fc188e49b15a77cf4.txt) — Contains exact KR hash; assertion scope still bounded by record
- [native-index/method-atlas/summary.json](../../../kr/evidence/b5621564b75a6eecf3eb300f16261099ff4972c72b2b490607544925c112da3a.txt) — Contains exact KR hash; assertion scope still bounded by record
