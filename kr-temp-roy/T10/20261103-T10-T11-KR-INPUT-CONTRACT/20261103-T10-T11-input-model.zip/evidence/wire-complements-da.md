# 既有 wire 補證界線與 S2C 00DA 最小原件閉合

## 範圍與結論

這是 T10/T11 父任務的只讀中間研究，接 `governance-sources.md`；不改本庫原稿、RR、Task、T01 狀態，不執行或附加 Client。本輪只為查清「既有訊息/欄位能否補證 physical direction-held」與 T09 舊稿 DA index 矛盾，沒有重做全量反編譯。來源先讀 T09 10/27、T10 W03/W04、T10-106、T02 E60/E84，再取原件三個小視窗，共419 bytes。

**在本輪已讀、已證的欄位範圍，沒有找到能把 ambiguous action-only 000A row 還原為 physical held/released 的額外 Client→Server 訊息。** 000B/000D 是 Server→Client 的 actor 移動/動作狀態更新，能證已同步/已執行狀態而非物理鍵盤狀態；00DA 只補充發送額度，且沒有 per-actor、方向或按鍵欄位的 consumer。這是有限來源結果，不是對全遊戲所有 opcode 的不存在證明。根任務仍須以實際 controller 的原件分支來證 action-only 的同值反例，不能把本節當成所有控制器一定模糊的先驗。

**S2C 補額度的 index 已閉合為 0x00DA，而非舊 T09 的0x78。** 此處的DA不是動作buffer，也不表示Server已受理五次普攻或允許五個pending action。

## 1. DA 的可重現原件依據

原始 `02-Tartaros.bin` SHA256 `9741d1975327b9309d82b52f631165bc410757694d7c183a5eed970a53ebef91`，size12472320；本節 `.text` raw=VA−0x400C00。範圍均end-exclusive，從合法函式入口順序解碼至所需區間，無執行原件。

### 1.1 表基址不能混用

既有 S04/T10-106 閉合：root R 的 callback物件在R+148、dispatcher在R+200；callback `4930E0` 讀 application首WORD，分類2才呼叫自身+B8（即R+200）的virtual4=`48AAD0`。S06/E84（20261101）再次確認分類及外層16-byte表，與下層 `FD2CF8→4FDA30` 的8-byte表不同。

本次原件 `48AAD0`：

```asm
48AAD7 mov ebx,[ebp+10h]             ; application key argument
48AADA movsx eax,bx                 ; signed low WORD
48AAE1 add eax,eax
48AAE4 mov edi,ecx                  ; dispatcher this = R+200h (S04)
48AAE6 mov ecx,[edi+eax*8+0Ch]       ; slot adjustment
48AAEA lea esi,[edi+eax*8]
48AAED mov eax,[esi+8]              ; handler = [R+208h+10h*K]
48AB34 lea ecx,[eax+edi-200h]        ; eax now saved adjustment
48AB3B call [ebp-8]                 ; saved handler
```

`493170` 的原件表初始化及實際覆寫：

```asm
493173 mov edi,494360h
493178 xor ebx,ebx
49317A lea edx,[eax+210h]            ; eax = R (S04 ctor provenance)
493180 mov esi,0BD5h
493185 mov ecx,0BF2375h
493190 mov [edx-8],edi              ; R+208h+10h*i handler
493193 mov [edx-4],ebx
493196 mov [edx],ecx
493198 add edx,10h
49319B dec esi
49319C jne 493190
...
4931F6 mov edx,4959F0h
4931FB mov [eax+0FA8h],edx
493201 mov edx,495A60h
493206 mov [eax+0F28h],edx
```

所以 `K=(0xFA8−0x208)/0x10=0xDA`；同視窗順帶可知 `0xF28` 對應 `0xD2`，舊稿列成`0x70`亦為算術錯。未在本輪重驗`495A60`內容，不新增其業務語意。只在本報告勘誤，不覆寫舊稿。

### 1.2 4959F0 的全部本體不讀 packet args

在一次性全域初始化檢查及兩個helper呼叫後：

```asm
495A44 83 05 B0 A7 FB 00 05    add dword ptr [FBA7B0],5
495A4B 33 C0                   xor eax,eax
... exception-stack cleanup ...
495A5C C2 0C 00                ret 0Ch
```

`4959F0..495A5F` 完整本體沒有從三個stack arguments讀取payload/長度/key，也沒有per-actor lookup、方向或鍵盤相位讀取。首次初始化helper的所有內部副作用不在本輪範圍，但本函式本體不存在把packet行解析成held的資料流。回傳0，不是callback特殊值0x100；不得將此回傳或+5稱為某次000A技能接受ACK。

T09/S01已定位 `FBA7B0` 初值30、每次有row送包後−1、此handler+5；根任務正在補必要clock/writer驗證。S01把它稱「移動封包回覆」是機能推測，沒有session pairing；較精確契約是**送出額度的Client全域狀態**。S01的F9423C=timeGetTime來源可復用；單程延遲BF74、四個傳送門檻與動作buffer時間必須保持分離。

### 1.3 方向同碼不代表同一訊息

S10/E38另已有C2S selector0 `00DA`、4-byte條件迴圈producer，出現在`4B7F00`角色清單後續初始化流程，以十筆`0x210`stride記錄的entry+5C gate決定是否送。它與本節S2C `00DA→4959F0`方向相反。不能因字面opcode一致，把C2S初始化欄位當成S2C credit payload，更不能把兩者當按鍵佇列。

## 2. 其他已知欄位能補什麼、不能補什麼

| 訊息/欄位 | 已有證據與精確位置 | 可補資訊 | 不能據此恢復的資訊 |
|---|---|---|---|
| C2S000A header+2 u32 | S08：545887讀F93944，54588D寫最終header | 保留原始opaque值；舊「stack殘值」已撤銷 | 沒有證為held bitmap、nonce、rowcount、時間或actor ID；不得用它補物理方向 |
| C2S000A first WORD | S08 Row A/B最終actor+4 | actor/row對應 | 不是key queue index，不含press/release |
| C2S000A fifth byte | S08/W00分支：A由具體callback；B初始E4，callback可寫，owner+58分支可覆寫B0 | 可依producer分支保留朝向/狀態取樣的原始值；根任務另核各controller | 相同朝向可同時出現在仍held和已release後；值自身不構成physical-held證據 |
| S2C000B，2+8N | S09：4AFE60；row{u16 actor,u8 state/heading,u8 flag,u16 x,u16 y}；4AFF49以flag bit0生成packed bit15；4B00E5寫actor+E0、4B00EF寫E4 | actor既有移動/朝向、受gate的位置修正；pointer identity match才owner+74分支 | Server送出的actor狀態不是Client鍵盤回報。不能從「上一筆Server認為移動」推「這一筆action-only方向仍held」 |
| S2C000D，2+9N | S09及20261101P0B：4B01C0；row{u16 actor,u8 state,u16 motion-adjacent ID,f32}；4C8A90、v58/v68/7A6970 | actor朝向/動作資源效果及position delta應用 | 無physical keys或held/release edge；未證000A逐包ACK或施放時按鍵快照 |
| S2C000C，2+3N | S09：4B0130；u16actor + signedbyte→actor+F0 v8 | actor子物件事件，與000D固定0xD進同接口 | 未證事件byte是攻擊成功、方向held、press/release |
| S2C0000，2+6N | S09：4AFAF0；u16actor/property/value；特定actor表property4→4CE914 actor+3E8 | 能影響未來546100→54F270的本地availability gate | property4不可任意命名物理鍵、冷卻或官方施放允許；不是已證input ACK |
| S2C00DA | 本節原件及S04/S06 | 全域送出額度+5 | 無actor/方向欄位consumer、不能分held/released、不是action buffer |
| C2S0022，7bytes | S08：54883A..883 logical17..20 phase1→50C640，offset+2 index1..4，+3 slot+8 DWORD | 另一類邏輯輸入事件/slot資料 | 不是已證四方向held；數字1..4不能因相同數量便命名方向 |
| C2S0068，3bytes | S08：548918..9B3，logical28..37 phase1，payload u8=ID−27，caller mode/FBA798 gate | 另一組索引事件 | 不含此producer已證的方向持續狀態；不是十階combo |
| C2S0007，3bytes | S08：548888..9EC，logical23/actor狀態，local可設0x80 | 有界local-state producer | 未證cancel/movement，更不能用其0x80充當000A的0x8000或physical-held |

### 2.1 000B → 000A Row B 是回授，不是額外鍵盤資訊

S09已比S01更精確地閉合：`4B00E5/Ef`寫同一actor的E0/E4；稍後Row B在`545A54`讀E0，`545A67/70`讀E4，再進virtual44與可能B0覆寫。這是**同一actor、符合owner vector、callback及sender gates時的跨時間state feedback**。它可能含Server先前提供的狀態，不能補回當時根本未編碼在row的物理鍵盤狀態。Server已有自己發送的E0/E4來源，重複讀回不會自動帶來新的held事實。

### 2.2 哪些結論必須保留未知

- 不聲稱已搜完3029個application keys，亦不聲稱不存在其它C2S physical-key channel。當前可供實作的已證來源中未找到該欄位，不能因為希望消歧便創造它。
- S09對0000/000B/000C/000D的row reads沒有識別出回傳F93944的nonce/serial。這限制「逐000A ACK」推論，不等於排除其它協定訊息或外部時序。
- 保留前一次moving或在action-only一律清moving，都是會選擇某種未知輸入歷史的Server策略；它們不是從這些補充欄位得出的物理held規格。根任務須以controller有效輸出建立移動/動作意圖，並將physical-held不可觀測性分開。
- 不提預設改Client；新診斷尚未有實測結論，只能維持使用者給定：依序四正向+Z整體回報不能移動，無四組獨立結果，舊152筆只有0A和長度不能回溯。

## 3. 新舊來源的使用順序

1. 000B/000C/000D/0000 field與actor consumer優先S09/W04及20261101P0B，避免舊T09直接叫ACK的過度語意。
2. 000A header優先S08/W03：原始F93944但業務語意未知。S01已更正stack殘值，S03的末尾仍沿舊header未知表述不能覆蓋新稿。
3. Clock/timeGetTime與main-loop order可復用S01/S02/S03；未將30或硬編1/30說成實際每秒穩定30tick。
4. DA first-layer dispatcher優先S04/S06並用本次原件三視窗閉合，取代S01「分派入口未找到、+FA8是0x78」；本報告不改舊稿、台帳或T01狀態。
5. S07/E66含廣場scene/controller constructor來源，已交keys_direction；本子任務不重查scene/controller，以免重複原件研究。

## 4. Git來源索引

以下均在固定main基準 `83959c0e7e65ab01348b285f03c285f487077610` 核得blob。20261101 P0B在原T10分支 `0419c66009a958597e95c9a88740d6f7f0d6772c` blob `02d09ab834d5f5b878a419a3391da76b9b077dc4`；其路徑與其它工作包已列 `governance-sources.md`。

| Ref | 路徑 | Git blob |
|---|---|---|
| S01 | `kr-temp-roy/20261027-084935-claude-web-roy-T09-send-throttle-header-and-server-authoritative-movement.md` | `5a86e1a7261e3ad08d7151ffb302793433944daf` |
| S02 | `kr-temp-roy/20261027-141326-claude-web-roy-T09-bulk-tick-rate-hero-driven-by-server-echo-and-actor-id-type.md` | `a7dc14d4dcf9458a0a9a1fdb681012a76071f149` |
| S03 | `kr-temp-roy/20261027-142007-claude-web-roy-T09-per-tick-frame-order-490FE0-4E0060-actor-update-loop.md` | `631002d75c005cd27794636588c084850a025ec6` |
| S04 | `kr-temp-roy/20261028-1942-chatgpt-web-roy-T10-106-queue-header-key-and-dispatch-bases.md` | `b9873d454eca75147c3251b85aed7f54929ecb5f` |
| S05 | `kr-extra-roy/20261030-113803-chatgpt-web-roy-E60-RR0007-KR-auth-roster-selection-scene-gated-S2C-dispatch.md` | `2ca02f3870d79d3217abf39b8651c43226eb77d6` |
| S06 | `kr-extra-roy/20261101-chatgpt-web-roy-E84-RR0007-outer-router-alternate-paths-native-review.md` | `a993238122a167222392a8c15c0c69061fe8e68a` |
| S07 | `kr-extra-roy/20261030-chatgpt-web-roy-E66-RR0002-square-handshake-43-68-6A-and-dual-state-RTTI.md` | `a802e8482af20145476015c17ee3dda029558f6c` |
| S08 | `kr-temp-roy/T10/W03-20261031/20261031-165757-chatgpt-web-roy-T10-W03-action-transport-native.md` | `62d31e8b3d8a450e644362092fd04e7ae696c729` |
| S09 | `kr-temp-roy/T10/W04-20261031/20261031-172536-chatgpt-web-roy-T10-W04-S2C-receive-actor-motion-native.md` | `8e915daab064177490d5de0b3f193810a5de2f41` |
| S10 | `kr-extra-roy/20261029-222122-chatgpt-web-roy-E38-RR0005-dispatch-slot2-key2-BB9-and-BD2-response.md` | `2e2d028db09f9262a38f9b9e36906e57a84b0931` |

## 5. 最小原件視窗

| 視窗 | VA 範圍 end-exclusive | raw start | bytes | SHA256 |
|---|---|---|---:|---|
| `48AAD0-dispatch` | `0x48aad0..0x48ab68` | `0x89ed0` | 152 | `8eab8912bc6b3904e9825f1a70c3515570e3655c374fb7bbe07d8fcbb95d4fb4` |
| `493170-first-slots` | `0x493170..0x49320c` | `0x92570` | 156 | `f74872dbc334e2a50509c3146f750dfbb8da15d536973482d353ae74b8109ab8` |
| `4959F0-DA-handler` | `0x4959f0..0x495a5f` | `0x94df0` | 111 | `a7fe8e0c2a199b9bbd8bd8653e0ce9ae7dae9426d5547975e0d6abe094e05d9c` |

對應反組譯保存在本scratch研究目錄三個同名 `.asm`；`wire-complements-provenance.json`保存機器可讀索引。此證明擷取一致及本文的有界分支，不提升為整函式語意FULL-PASS或Task完成。
