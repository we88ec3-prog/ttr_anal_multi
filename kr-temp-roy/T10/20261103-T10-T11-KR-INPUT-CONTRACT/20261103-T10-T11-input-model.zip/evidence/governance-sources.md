# KR T10/T11 前置與既有來源查核（只讀索引）

## 版本、執行與定位

- 本輪主線基準：`83959c0e7e65ab01348b285f03c285f487077610`；既有 T10 工作分支基準：`0419c66009a958597e95c9a88740d6f7f0d6772c`。
- 這是父任務的中間來源索引，不是新增原生分析、T01裁決、RR台帳或交付完成宣告。僅讀Git原件文字及凍結review JSON，沒有執行或修改Client，沒有改GitHub、Task owner、RR、分支。
- 必讀入口均已閱；T10/T11 task.json owner=null/state=unclaimed/native_complete=false只反映登記，不否定本輪使用者明確派工。
- RR index共10項，無owner_task=T10或T11；兩收件箱均無待處理RR。當次工作包以使用者本輪指示為準，不虛填CLAIMED/SUBMITTED/ACCEPTED。
- shared/verified-knowledge README列8筆有界FULL-PASS，無輸入/0A/技能buffer正式條目；不能據此宣稱原稿沒有既有研究。

## T01退回與修正版本

T10 README有7筆：116/062/063/007/026為NEEDS_FIX，055/056為NEEDS_QUALIFICATION。T11 README無退回專節。

| 項目 | 應復用的更正與邊界 |
|---|---|
| 116 ROW5 | Row B caller在virtual44!=0、owner+58==0時跳過B0覆寫；若callback未改out+4才保持R+E4。Row A 5458CA在兩次push後寫S+18，不是S+38；546100才初始化out+4並可後續改寫。不可把row fifth byte無條件叫B0/方向。W00-116已有完整勘誤。 |
| 007 | 5467F1是指標load；5467F4才WORD store。三路OR及byte選擇主要資料流保留。 |
| 026 | 549D54屬549C60，不能歸549980。 |
| 062 | 普通40-byte clear早於可選6D1DA0，非先init再clear。 |
| 063 | clear writer無reader的ESI<=27 guard。 |
| 055/056 | 原視窗從指令immediate中開始，假CALL／指令不可信；用合法入口重解碼的修正版。 |

七份W00勘誤已在main；T01 `research/handoffs/t01-20261031-t10-w00-w05-native-review/README.md`（blob d978ee1e8f090e28bb996d2600b58b020ed81347）有主張級R2支持，但明示尚未R3/FULL-PASS，README退回仍維持。不可把「已有勘誤」說成RESOLVED，亦不可把README仍退回誤說成尚無修正版。與本輪直接相關的116/007應優先應用；其它退回保留原狀，因使用者定向輸入/動作工作包不重做無關主題。

## 優先復用來源及實際內容

1. **W01**：完整物理鍵盤取樣→manager held/raw phase→KeyMapping mapped phase0/1/2/3→UI消耗→controller+5C bitmask；Type0 Z/X/C=logical13/14/15，Type1不同；current bank、mode0 alternate+260 producer有限未知。logical13/14/15/22/24/25/26 → OR1/2/4/10/3/6/5。UI先清phase不保證controller無殘留，不等於整幀無封包。
2. **W03 combo**：Z+X=mask3→SkillMatrix col4；Z+C=5→col5；X+C=6→col6；0x07 predicate優先col4。這是Client本地順序，不是原版Server固定分支證明。雙鍵不等Row A/B；mask可在同一row highWORD，callback/owner+58可清。Row A固定三槽；B是vector/tree。既有原稿已說`5463FB/546440`設bit15、`546406/54647C`可清，必須讀完整CFG，不能只看單AND/OR。
3. **W00-116**：第五byte逐分支資料流及retN/ESP，是本輪row解讀優先勘誤。
4. **W05**：54F270 matrix/timer availability、54F200每visit減1、545E20的8+6N buffer及signed count/33、SubAI三欄非負檢查；並未證一般玩家資源扣款/官方時間。後來分支20261101 T11稿已補012A入口，讀較新稿避免重做。
5. **T09 20261026 001843**：546100/546780/546850較早完整筆記，含方向向量合成及8方向量化，當時key名與相機語意有限未知。其「8000欲移動/移動中」明標推測，不是physical held結論；應由本輪最小BIN查證。
6. **T09 20261026 043549**：5452C0三槽與000A初版；header+2來源與RowB當時仍未知，已被較新W03和T10-115補齊，不能回退採舊未知或錯誤Row5泛化。
7. **T09 20261026 174312**：S2C索引0A為群組成員清單→CController三槽，與C2S000A不同方向/不同結構；作slot provenance候選，可避免把多actor row當按鍵佇列。
8. **分支20261101 P0A**：CTutorialController C0FB1C+48→548D10→546100；sender gate根據FBA7B0取100/120/180/300，再max(2*BF74)，delta需超過；這是傳送節流，不是combo期限。發送後+64更新、+74/+5C/+58 reset。多row先A後B，不做actor ID dedup；結構可能重複，不代表已觀測首戰重複。
9. **S00既有工作卡**：research/handoffs/s00-web-skill-gap-20261101/README.md及FOLLOWUP-02；記錄v7首戰連點/受擊問題與0.4s Server候選。較新的本輪v14-v16實測敘述優先，不能由v7舊卡替代。main/這些S00範圍未找到本輪命名input-contract/key-combinations/action-buffer交付。
10. **S00 intake**：明示已收commit4064846三份但未merge main，七視窗hash只有限佐證；保留FirstWord/SecondWord/OpaqueByte；同actor多row不擅自last-wins。可引用不必再從零研究transport。

## 七個候選的凍結bulk review

下表來自20261026凍結`review-status.jsonl.gz`。全數`full_function_semantic_review=not-recorded`、`related_bounded_evidence=[]`、`registration_is_review=false`。這是當次bulk保存狀態，不覆蓋後來W00–W05有限R2。

| Address | 函式衍生文字SHA256 | Registered task |
|---|---|---|
| `0x5452c0` | `e11265c9aca8d18800425293f9ed3bea7fdaf94a250e936a8e9cae007e1fa688` | T10 |
| `0x546100` | `efe4a819412268e6c29b45ccdfa1b9e7cdf81ed38a40e75e5f9d0851efeb9a91` | null |
| `0x546780` | `f84824a5c32e16aad03721ad0c7bd2c86a4b1c20142ba67dccc515efd5603b6e` | null |
| `0x546850` | `18a354df8922b676961c4261a5c820dc704b6b7228a8f5652c5cdaf3d524dc52` | null |
| `0x546b50` | `a3f4abdab94ce7c3ceed86fc20aa7dd9cf8ef23b60b98b2ff5b7e35981d56157` | null |
| `0x546d50` | `3745cb0dc604006bb3c6cbc76a2f9b38f88cc05bd32fb8f30b3e8a8d23ea3b35` | null |
| `0x548350` | `a6768828e137dd6f987079a378a601fca646cd52fec854f423ccde5b9da04391` | null |

## 精確Git來源清單

表內都是實際`git rev-parse commit:path`核得的blob，不是下載檔案hash。列名含來源版本。W02與分支P0B/T11最初僅確認精確來源、交相關子任務閱讀；W04已在後續wire補證子題讀取其000B/000C/000D/0000相關全部段落。本文不冒稱已全文原件複驗所有語意。

| Version | Path | Blob |
|---|---|---|
| `83959c0e7e65` | `AGENTS.md` | `d8aa503c6970c626a11310988ebb1db8ee5e2d6c` |
| `83959c0e7e65` | `kr/tasks/T10/README.md` | `a409f168e9a67ae1cf6ba76393aad08a9caf37ad` |
| `83959c0e7e65` | `kr/tasks/T10/task.json` | `5ffeb6a3e375513d463bf3550e6c9891b6ecccc3` |
| `83959c0e7e65` | `kr/tasks/T11/README.md` | `a6b1294c755802a82ad9e9f2cb366a0627d17346` |
| `83959c0e7e65` | `kr/tasks/T11/task.json` | `f71cd35f5e30233c689c9716365cf2f4eb4eecca` |
| `83959c0e7e65` | `research/dispatch/README.md` | `c7bfbfcdacf485e5468788a5d96b2ad69f9925db` |
| `83959c0e7e65` | `research/dispatch/inbox/T10.md` | `0c602bd7c7a3763ff9ebbdf7218a9032bf353160` |
| `83959c0e7e65` | `research/dispatch/inbox/T11.md` | `81889b4c4947807bb3263d125d015824144cb50b` |
| `83959c0e7e65` | `research/requests/index.json` | `b5c169d07b26501615ad47988705a32020afcc67` |
| `83959c0e7e65` | `shared/verified-knowledge/README.md` | `710e76a446ff807e4d49c724cbc734fcf21c9481` |
| `83959c0e7e65` | `shared/integrations/T01-BULK-20261026-02/README.md` | `441605b41f9ec9aa5062d563af06a84f8a245fa0` |
| `83959c0e7e65` | `research/handoffs/t01-20261031-t10-w00-w05-native-review/README.md` | `d978ee1e8f090e28bb996d2600b58b020ed81347` |
| `83959c0e7e65` | `kr-temp-roy/T10/W00-20261031/20261031-060240-chatgpt-web-roy-T10-W00-116-correction.md` | `bb5f5972d4d0bf0ac91bf944aeb82ffd39d00804` |
| `83959c0e7e65` | `kr-temp-roy/T10/W01-20261031/20261031-154059-chatgpt-web-roy-T10-W01-input-source-to-action-gates.md` | `a5d6c4ca0104e8ffba51e151169f6072f09035d4` |
| `83959c0e7e65` | `kr-temp-roy/T10/W02-20261031/20261031-163141-chatgpt-web-roy-T10-W02-basic-attack-as-skill-native-difference.md` | `e8a0cedc28c28968905e914d01379915fe9dc17f` |
| `83959c0e7e65` | `kr-temp-roy/T10/W03-20261031/20261031-165757-chatgpt-web-roy-T10-W03-action-transport-native.md` | `62d31e8b3d8a450e644362092fd04e7ae696c729` |
| `83959c0e7e65` | `kr-temp-roy/T10/W03-20261031/20261031-170644-chatgpt-web-roy-T10-W03-combo-mask-row-producer-closure.md` | `0d17362eb300ab8ea002c3d6380d5a41039665bc` |
| `83959c0e7e65` | `kr-temp-roy/T10/W04-20261031/20261031-172536-chatgpt-web-roy-T10-W04-S2C-receive-actor-motion-native.md` | `8e915daab064177490d5de0b3f193810a5de2f41` |
| `83959c0e7e65` | `kr-temp-roy/T10/W05-20261031/20261031-182635-chatgpt-web-roy-T10-W05-skillmatrix-resource-timing-T11-handoff.md` | `b3c0f31db311cce06f3a87fcbbf4f938171ce972` |
| `83959c0e7e65` | `kr-temp-roy/20261026-001843-claude-web-roy-T09-hero-input-record-546100-546780.md` | `6002bce2ee0c18ecccf0093ffa115334bead659f` |
| `83959c0e7e65` | `kr-temp-roy/20261026-043549-claude-web-roy-T09-controller-frame-5452C0-input-packet-0x0A.md` | `a4623aafbddde000c865ccb70f14f6ef92d5a268` |
| `83959c0e7e65` | `kr-temp-roy/20261026-174312-claude-web-roy-T09-cmd-0x0A-handler-4AF920-controller-slots-and-coord-space.md` | `bd806146ee799578e6acc8c099d574ecf4aba73e` |
| `83959c0e7e65` | `research/handoffs/s00-web-skill-gap-20261101/README.md` | `505f4706667ab2f348278bda8f4805175e19e16c` |
| `83959c0e7e65` | `research/handoffs/s00-web-skill-gap-20261101/FOLLOWUP-02-V7-COMBO-AND-HURT.md` | `47bff869dca72dcad4bc4a70c8df87295af0d216` |
| `83959c0e7e65` | `governance/s00-iterations/S00-20261101-WEB-COMBAT-INTAKE.md` | `bbb9cc5a7d3c4e2bc088d067e4d5fc0adf008ce5` |
| `0419c66009a9` | `research/handoffs/s00-web-skill-gap-20261101/20261101-T10-NATIVE-ROW5-T01-ERRATA.md` | `adb3b4fd1557dd3fffb50f37699d89ef0b634586` |
| `0419c66009a9` | `research/handoffs/s00-web-skill-gap-20261101/20261101-T10-P0A-V7-Z-INPUT-ROW-CLOCK-BOUNDARY.md` | `d5de9db6fb6db5fccb837abd5be7e50ca5156d12` |
| `0419c66009a9` | `research/handoffs/s00-web-skill-gap-20261101/20261101-T10-T11-P0B-KR-000E-VTABLE-VS-000D-MOTION.md` | `02d09ab834d5f5b878a419a3391da76b9b077dc4` |
| `0419c66009a9` | `research/handoffs/s00-web-skill-gap-20261101/20261101-T11-KR-SKILL-012A-GATES-BOUNDARY.md` | `3691a72a7177c5fb91767cc01a4caf030375f304` |
| `0419c66009a9` | `research/handoffs/s00-web-skill-gap-20261101/20261101-T10-T11-S00-SERVER-HANDOFF.md` | `e6667c813971d1f81bec9cbbd030fbb63d697984` |

## 後續補證索引

`wire-complements-da.md` 新增既有T09 20261027 clock/frame來源、T10-106與T02 E60/E84 dispatcher來源，及原件三小視窗閉合S2C00DA（舊T09誤算0x78；正確為(FA8−208)/10h=DAh）。4959F0本體只在一次初始化後將FBA7B0加5、返回0，不解析packet args。000B/000D等既有訊息只補actor移動/動作狀態，未找到可補physical-held/released的額外已證C2S欄位；有限來源否證，不是全遊戲不存在證明。
