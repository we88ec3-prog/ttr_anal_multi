006F3A80 raw=002F2E80 b8 1c 08 c4 00            mov      eax, 0xc4081c
006F3A85 raw=002F2E85 c3                        ret      
