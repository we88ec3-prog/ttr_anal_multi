
/workspace/scratch/30cfcc0720c4/project_sources/02-Tartaros.bin:     file format pei-i386


Disassembly of section .text:

004959f0 <.text+0x949f0>:
  4959f0:	55                   	push   ebp
  4959f1:	8b ec                	mov    ebp,esp
  4959f3:	83 e4 f8             	and    esp,0xfffffff8
  4959f6:	6a ff                	push   0xffffffff
  4959f8:	68 ee 61 94 00       	push   0x9461ee
  4959fd:	64 a1 00 00 00 00    	mov    eax,fs:0x0
  495a03:	50                   	push   eax
  495a04:	51                   	push   ecx
  495a05:	a1 20 1f d6 00       	mov    eax,ds:0xd61f20
  495a0a:	33 c4                	xor    eax,esp
  495a0c:	50                   	push   eax
  495a0d:	8d 44 24 08          	lea    eax,[esp+0x8]
  495a11:	64 a3 00 00 00 00    	mov    fs:0x0,eax
  495a17:	b8 01 00 00 00       	mov    eax,0x1
  495a1c:	84 05 2c b2 fa 00    	test   BYTE PTR ds:0xfab22c,al
  495a22:	75 20                	jne    0x495a44
  495a24:	09 05 2c b2 fa 00    	or     DWORD PTR ds:0xfab22c,eax
  495a2a:	c7 44 24 10 00 00 00 	mov    DWORD PTR [esp+0x10],0x0
  495a31:	00 
  495a32:	e8 59 92 04 00       	call   0x4dec90
  495a37:	68 30 ce bc 00       	push   0xbcce30
  495a3c:	e8 d9 c8 3f 00       	call   0x89231a
  495a41:	83 c4 04             	add    esp,0x4
  495a44:	83 05 b0 a7 fb 00 05 	add    DWORD PTR ds:0xfba7b0,0x5
  495a4b:	33 c0                	xor    eax,eax
  495a4d:	8b 4c 24 08          	mov    ecx,DWORD PTR [esp+0x8]
  495a51:	64 89 0d 00 00 00 00 	mov    DWORD PTR fs:0x0,ecx
  495a58:	59                   	pop    ecx
  495a59:	8b e5                	mov    esp,ebp
  495a5b:	5d                   	pop    ebp
  495a5c:	c2 0c 00             	ret    0xc
