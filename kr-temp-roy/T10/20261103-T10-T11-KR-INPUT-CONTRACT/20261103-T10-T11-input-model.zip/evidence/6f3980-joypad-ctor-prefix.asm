006F3980 raw=002F2D80 57                        push     edi
006F3981 raw=002F2D81 33 ff                     xor      edi, edi
006F3983 raw=002F2D83 68 00 08 00 00            push     0x800
006F3988 raw=002F2D88 8d 86 1c 01 00 00         lea      eax, [esi + 0x11c]
006F398E raw=002F2D8E 57                        push     edi
006F398F raw=002F2D8F 50                        push     eax
006F3990 raw=002F2D90 c7 06 48 24 c4 00         mov      dword ptr [esi], 0xc42448
