# KR T10/T11 定向補證：按鍵、方向量化與場景控制器

研究者：keys_direction 子工作。基準 main `83959c0e7e65ab01348b285f03c285f487077610`；原件 BIN SHA256 `9741d1975327b9309d82b52f631165bc410757694d7c183a5eed970a53ebef91`。本稿只做原件唯讀定向 x86 反組譯、PE/RTTI 讀取與既有稿復用，沒有執行、附加、修補 Client，沒有重新全量反編譯，也沒有任何 Git 寫入。

前置已讀 AGENTS、T10/T11 README/task.json、inbox。T10/T11 收件箱沒有待處理 RR；T10 既有退回保留，由主工作處理相關 W00 勘誤。本稿不自改 RR、owner、FULL-PASS 或原稿。`keys-direction-evidence.json` 保存精確 byte asserts（全相符）、原件視窗 SHA256、frozen per-function review records、RTTI 和既有來源 blob；個數以JSON為準。所有這些 frozen function reviews 仍為 `full_function_semantic_review=not-recorded`，不可升格整函式 FULL-PASS。

## 1. 先用既有來源，再補查缺口

| 代號 | 既有來源（repo 相對路徑） | Git blob | 本稿復用範圍 |
|---|---|---|---|
| K-MAP | `kr/evidence/6194d2ff4b51eacfb64b03698a10dfea57041b2e714de9a762ea139fffe82b18.txt` | `cb8a9da734567b10e37cc966a981300cb3e7b8bc` | 真實 KR KeyMapping Type0/Type1 |
| K-W01 | `kr-temp-roy/T10/W01-20261031/20261031-154059-chatgpt-web-roy-T10-W01-input-source-to-action-gates.md` | `a5d6c4ca0104e8ffba51e151169f6072f09035d4` | DirectInput、logical phase、UI 清除、mask producer |
| K-W03 | `kr-temp-roy/T10/W03-20261031/20261031-170644-chatgpt-web-roy-T10-W03-combo-mask-row-producer-closure.md` | `0d17362eb300ab8ea002c3d6380d5a41039665bc` | OR 和弦、matrix column、Row A 的條件式保存 |
| K-DIR | `kr-temp-roy/T10/20261027-chatgpt-web-roy-T10-10-direction-byte-synthesis.md` | `e6f414aa1601f0078df0e6cd88b57752a36f867c` | 546850 四個 mapped phase 及離散角度 |
| K-T09 | `kr-temp-roy/20261026-001843-claude-web-roy-T09-hero-input-record-546100-546780.md` | `6002bce2ee0c18ecccf0093ffa115334bead659f` | 方向 collector 優先次序及 callback 基本資料流；舊的 mouse 推測不沿用 |
| K-ANGLE | `kr-temp-roy/20261025-231655-claude-web-roy-T09-collision-users-probe-545F30-and-direction-table.md` | `1c34936296b1bcf63bd905aad80d4270bbf48cab` | 256 向量表與角度轉 byte |
| K-E66 | `kr-extra-roy/20261030-chatgpt-web-roy-E66-RR0002-square-handshake-43-68-6A-and-dual-state-RTTI.md` | `a802e8482af20145476015c17ee3dda029558f6c` | S2C69/7→CSquare→4BBC10；原稿附錄已有 Single 建構呼叫 |
| K-SCENES | `kr/evidence/8762287177ecd19a4bf1b4a21c8e311a58733e962b1bacc28c6c1461e02b7bb3.txt` | 見audit JSON | 已有四場景init→controller種類及新手教學／CTutorial名稱界線 |
| K-FORM | `kr/evidence/1db3c9b6a84258433cee91db91c0346ddfffea5045bfedb274073b6ce633d0d9.txt` | 見audit JSON | 既有547F90／5480A0／5480E0工具輸出，僅作新BIN窗口候選 |
| K-SUBAI | `kr-temp-roy/T10/20261027-211146-chatgpt-web-roy-T10-30-subai-actor-state-counter-and-branches.md` | 見audit JSON | 548FF0本地候選更新及output writer；不混為物理按鍵 |
| K-SIDE | `kr/evidence/91830956fb04388f5eabd1c876f283c6e78e9f001e953e978345472ff3572866.txt` | 見audit JSON | 先前Single本機拾取相關sidepath及A4/38C特例；非普攻語義 |
| K-INTERACT | `kr/evidence/c04a004606b26865dd9e351e6cac35af96b885056d6223264455a4680207da5a.txt` | 見audit JSON | 既有NPC互動range/latch/manual與v+64路由；不將舊Server v7驗證升為本輪結果 |

本稿新增查證重點是把已知 logical 方向與 K-MAP 接合、明確取樣／量化方式、以 RTTI 和 ctor 區分 Square/Single 與 MissionRoom，以及排除把 546D50 當滑鼠游標的舊推測。

## 2. Physical / mapped held / phase / action mask 是不同層

以下為 K-W01 已存證，未在本子工作重做全部鍵盤 COM 路徑。

1. `6F16B0` 各 device sample，`6F1790` 合併 held bytes 到 input manager+60，並產生 raw phase+160。正常 keyboard wrapper 以 `6F38A0` Poll/GetDeviceState(256) 讀裝置。
2. `6D1480` 依目前 bank 的 Key/ModKey 讀輸入。`manager+20!=0` 選+60，否則選+260；+260 的全部 producer 尚未閉合，不能當成永久一般 keyboard 模式。
3. `6D1915..6D19B6` 用上一輪／本輪 mapped held 產生 40 個 logical phase，`0=idle, 1=pressed, 2=held, 3=released`。`6D19CD` 複製 current 到 previous；`6D19F2` 還可被注入事件列表覆寫，這些 mapped phase 不是完整硬體歷史。
4. 已證的一條 frame order 先 sample／map，後 UI/event consume→`490D40` 清部分 phase，才 `4E0060` dispatch controller tick。UI清除某 logical phase，不等於同時清 controller+5C 或所有其他 producer。
5. `5452C0` 的 phase13/14/15 **1或2** 分別 OR 1/2/4 到 controller+5C；`546850` 的 phase1/2/3/4 **1或2** 分別影響方向。兩者都把 pressed 和 held 視為有效，後端不能由這種 row 還原邊緣型別。

組合遺失／合併點：相鄰 sample 之間完整發生按下再放開，sampled held可能看不到；UI可能清單一logical phase；controller OR丟失按下的時間先後及原始鍵位；方向相加會合併相反鍵；546780只選一個heading，未帶出所有裝置候選。這些是相應 code/資料結構可推出的資訊邊界，不是對玩家本次實測所發生事情的判決。

Type0 與等價目前 bank 才可把實體名稱映到以下 logical ID：

| 物理鍵 | K-MAP Key index | logical ID |
|---|---:|---:|
| 上 | 200（亦有72） | 1 |
| 下 | 208（亦有76/80） | 2 |
| 左 | 203（亦有75） | 3 |
| 右 | 205（亦有77） | 4 |
| Z | 44 | 13 |
| X | 45 | 14 |
| C | 46 | 15 |

Type1 的方向改為 W/S/A/D 的17/31/30/32；Z/C/V映logical10/11/12。預設DefaultType=0不證明玩家實際bank未變。Server不應把wire mask還原成必然某個實體鍵。

## 3. 546850 的四正／四斜：相加、相消、截斷量化

本次重讀原件 `546850..546B46`；全段rooted disassembly另存`546850.asm`。令 `E(i)=phase[i]∈{1,2}`：

```cpp
dx = E(2) - E(1);  // 下 - 上; native local [ebp-18]
dy = E(4) - E(3);  // 右 - 左; native EDI
if (dx==0 && dy==0) return 0; // out byte 不改
out = uint8_t(octant(dx,dy) + yawByte);
return 1;
```

這裡的 dx/dy 只是兩個運算變數，不把它們誤名為世界座標 x/y。原件`5468EE sub [ebp-18],ecx`、`546965 add [ebp-18],ecx`、`5469DC sub edi,ecx`、`546A52 add edi,ecx`（ECX=1）直接支持相加／相消。

| 按住方向 | dx,dy | base heading | 實際collector heading |
|---|---|---:|---|
| 上 | -1,0 | 0x80 | uint8(0x80+Y) |
| 下 | +1,0 | 0x00 | uint8(0x00+Y) |
| 左 | 0,-1 | 0xC0 | uint8(0xC0+Y) |
| 右 | 0,+1 | 0x40 | uint8(0x40+Y) |
| 左上 | -1,-1 | 0xA0 | uint8(0xA0+Y) |
| 右上 | -1,+1 | 0x60 | uint8(0x60+Y) |
| 左下 | +1,-1 | 0xE0 | uint8(0xE0+Y) |
| 右下 | +1,+1 | 0x20 | uint8(0x20+Y) |

`Y=uint8(trunc_toward_zero(float([[FB76E8]+20])*float[FB8824]))`。`546ACA`取角度欄位，`546AE6..546B09`乘轉換因子，`546AF6 OR EAX,0C00`、`546AFE FLDCW`、`546B01 FISTP`，明確設定x87 toward-zero後轉整數再取低byte。bulk偽碼的`ROUND()`不可解讀為四捨五入。`4BB450`也以相同OR0C00/FISTP做一般angle→byte，原件`4BB47C/484/487`已核。

K-ANGLE的`4449D0`以step≈2π/256建立256方向，FB8824=1/step；所以本運算為360°/256單位，keyboard八向base間隔32=45°，再加當次角度偏移。這不是只允許八個絕對wire值；camera偏移及後段碰撞候選可使最終byte不同。無camera當時值不可把上固定寫成0x80的實測wire斷言。

相反方向：同一取樣中上＋下相消、左＋右相消。此collector沒有last-key時間戳，也沒有先按方向勝出的分支。若四鍵全有效，回0且不改out；其後546780仍可能選其他來源，因此不能全域稱無方向。先後按下且跨sample則有不同phase序列；按下先後落在同一sample間隔時，這條路沒有保存完整順序。相反方向／特殊多鍵僅作靜態說明，實際操作留待排程，本輪不聲稱測過。

### 3.1 546780 的heading選擇優先與資訊不可逆

三個collector都會依序被呼叫：`5467CD→546850`、`5467E0→546B50`、`5467EC→546D50`，不是第一個成功就不執行後兩個。`5467F4`寫action候選WORD後，heading優先取**546850 keyboard logical方向**（`5467F7..546804`）；只有它回0才取546B50（`546811..54681E`），再失敗才取546D50（`54682B..546836`）。三路皆無結果則保留呼叫者預填heading。return值是三路結果bitwise OR，不能據此還原究竟哪個方向來源被選中，更不等於keyboard方向鍵held。

例如在同一sample之前依序按左、上，與依序按上、左，只要當次mapped有效集合都是{上,左}，本collector都產生`A0+Y`；行內沒有可保留兩者歷史的順序欄位。相對地，若兩次按下跨sample，可以先形成左後左上或先上後左上，但5452C0的發送gate仍可把多次sample合併到較晚的row。Z的phase1與2同OR1；未取樣到的Z放開／再按，不可從同mask row重新創造出兩個pressed事件。這是資訊流本身的多對一性，不是一條可用固定last-key填補的規則。

## 4. Z+X 與 Z+C 是有獨立consumer規則的mask，不是數字相加猜想

K-W03已逐指令驗證：logical13/14/15有效時各OR1/2/4；logical24/25/26另可OR3/6/5，其上游不完整，不能稱為已證硬體和弦判定器。

| Type0 有效logical輸入 | controller候選mask（無舊位／其他producer） | 54F270已證本地可用性欄位 |
|---|---:|---:|
| Z | 0x0001 | column1 |
| X | 0x0002 | column2 |
| C | 0x0004 | column3 |
| Z+X | 0x0003 | column4 |
| Z+C | 0x0005 | column5 |
| X+C | 0x0006 | column6 |
| Z+X+C | 0x0007 | 本predicate先命中column4 |

`54F270`按0xC0特殊bit、bit0&1、bit0&2、bit1&2、單bit順序短路；這是已證程式分支優先，不是Server固定按鍵優先。Z+X與Z+C是不同column；Server若把mask拆為兩次施法／兩次消耗，沒有這份Client證據支持。反過來，該predicate也不是正式施放成功、最終選招、buffer消費或官方Server決策。

**左上+X**：方向collector可提供`uint8(A0+Y)`，action候選`2`。**左上+Z+X**：同一方向collector與action候選`3`可同時存在。**Z+C**：action候選`5`，若無方向collector成功，heading可沿caller預填actor B0。上述是同次收集可同時表達的值；最終wire須通過546100／owner gates，不能把候選mask當wire必然值。尤其主工作已驗546100低15位非零時跳過兩個OR8000寫入點，須在最終契約引用主工作的完整CFG。

技能是否朝左上：此輸入介面可帶斜方向，不支持「技能只四向」限制；真正S2C執行heading及Server選取哪一個時刻，需要結合主工作的receive/buffer證據。僅此collector可確定heading在本次callback即時取sampled方向／角度欄位，而不是附有原始按鍵時刻的immutable queue記錄。

## 5. 廣場不應誤套548350：具名RTTI與ctor接合

K-E66已有S2C69 subtype7→4BBB70→Scene::CSquare vptr C06FB0，scene vslot10=4BBC10。本次補核`4BBD8F call548540`，`4BBD9E [FBA7A4]=EAX`；`548577 [this]=C0FAC4`，`5485D6 [FBA7AC]=2`。因此正常CSquare entry新建 **CSingleController**；mode2既有controller時可走544F50重用分支，這個分支不另由名稱推斷其runtime內容。

| 具名RTTI | vptr/COL/TypeDescriptor | tick +2C | row callback +48 |
|---|---|---|---|
| CController | C0F944 / C6C5B4 / F7C6AC | 5452C0 | 546100直接 |
| CEmptyController | C0F99C / C6C5C8 / F7F534 | 8DC2F0，return0 | 547230，return AL=0、不寫out |
| CFormationController | C0FA14 / C6C614 / F7F554 | 547F90 | 5480A0：slot0→546100；slot1/2→5480E0 |
| CSingleController | C0FAC4 / C6C6AC / F7F5A0 | 548A90 | 548A20 |
| CMissionRoomController | C0FA6C / C6C660 / F7F578 | 548350 | 546100 |
| CTutorialController | C0FB1C / C6C6F8 / F7F5C0 | 548CB0 | 548D10 |
| CTagController | BFB5A4 / C6689C / F7C6C8 | 444670 | 548A20，與Single同callback；本輪不展開Tag tick |

這些名稱讀自BIN RTTI `.?AV...@@`，不是猜class名。以上七張已知表的+44皆為546EF0。K-SCENES已有 `CMissionField→CSingleController(kind2)`、`CMissionRoom→CMissionRoomController(kind1)`、`CScenarioField→CFormationController(kind3)`、`CTutorial→CTutorialController(kind4)`。遊玩流程名「新手教學」不等同每刻都用CTutorial；劇情戰鬥可換CScenarioField／Formation。它們和本稿Square新建Single的閉合一起限制context選擇，仍不能單靠玩家口述「戰鬥」決定vtable。

### 5.1 Single / Square 正常分支

`548A90`先檢查this+4，成立後`548AD2 call5452C0`。之後才處理actor/action相關欄位，並在`548B5E cmp [FB9011],1`把Z的**pressed-edge**轉成bool參數，再`548B74 call544A00`。phase1傳true，其餘phase傳false，兩者仍都呼叫434250／544A00；不能寫成其他phase根本不進互動函式。同一logical13在builder累積時接受1/2，在此轉為phase1布林；後續還有manual／自動互動分流，二者語義不可合併。

`548A20`在actor存在且actor+38C!=0x10且controller+A4==0時，清+BC並在`548A47`尾跳`546100`。若actor+38C==0x10或+A4!=0，直接把out+4寫該slot actor+B0、out+2清0、+BC設1，僅+BC原為0才回true一次。這是具體抑制輸入／送一次清狀態的分支；但不得無證把actor+38C==0x10命名為任何技能中，也不能說凡Z必進這支。

**A4 的一個已證 writer 不是 Z**：沿K-SIDE已有sidepath，本次核原件`548B12 lea ecx,[controller+88]→548B19 call49C5C0`；`49C5FC EDI=ECX`。`49C74F`讀`FB901B=logical23`，phase1分支在`49C772 EAX=1`、`49C77D [EDI+1C]=EAX`，即寫controller+A4=1。K-MAP Type0／Type1的logical23皆為Key57（Space）。該sidepath在builder之後才執行，所以對下一次callback的狀態有影響；不是本輪已發出的row被倒改。`49CC36`是同alias欄位的清除路徑；caller的actor條件未過則`548B22`直接清A4、`548B28`清AC。這只閉合一組正常writer／consumer，沒有假裝窮盡所有alias writer。

**Z互動入口自身能證到哪裡**：K-INTERACT已有`544A00→544730`的距離／enabled／manual／重複鎖存規則，本輪核原件與之相符。`544730`只直接改互動物件+104及呼叫者local結果／距離，未直接改0A row或controller+A4。`544A00`挑最近可啟動候選，`F942C0==0`時在`544B2D`呼叫該物件vtable+64；既有CCheckPoint表可路由544070，再依kind進UI／事件分支。本輪未窮盡各v+64及UI後續抑制來源。故精確答覆是：**普通Single輸入路徑只要保留非零action低15位，546100便不寫移動bit15；這成立與NPC互動是否成功是兩件事。額外A4／38C清狀態及UI焦點消耗亦存在，但不能宣稱每次非戰鬥Z都必然觸發它們。**

### 5.2 548350 MissionRoom

`54837B/37F` this+4 gate後，`548393 call5452C0`，後面才有本地room/UI檢查。整個`548350..54853B`沒有row+2的8000直接寫入；它復用虛表+48的546100。因此後面return0不能倒推出先前沒有建0A／送0A。這也不等於MissionRoom無UI抑制；frame前的UI phase清除與546100本身gates仍存在。

### 5.3 Tutorial

`548CB3/548CBD`檢查this+4與+DC非零，`548CC7`才call5452C0；row callback`548D14`尾跳546100。+DC gate是已證額外允許條件，其writer/正式名稱不在本子工作冒稱。其互動入口用configuration+7E1，不像Single直接用logical13 pressed。教學／廣場不能只用同一按鍵名稱推定全部處理相同。

### 5.4 Formation：主控角色與副角色不得一律套546100

第五byte的完整有界細節已補於同目錄`formation-secondary-row-detail.md`：5480E0的E4只是比較快照，不是O+4初始化；548FF0 publish才複製A+74，seed、early-return、後段emit／bit15順序須按該增補解讀。

`547F90` tick有this+4 gate；`547FCB call5452C0`之後才`548002 cmp [FB9011],1→548018 call544A00`。正常Z互動edge在builder後的順序與Single相似，但slot callback不同。

`5480A0`先查`this+0C+12*slot` actor存在；slot0在`5480D0 call546100`；非0 slot在`5480C1 call5480E0`。主迴圈只提供slot0..2，所以本已證正常範圍的非0為slot1/2。`5480E0`本輪只定向核到具體output與gate，沒有重做其所有candidate AI callee：

- `548141/147`保存該actor的E0/E4作比較。`5481B3 call548FF0`用本地CAIControl物件FB7A28、主actor／另一副actor與slot index產生候選5-byte state；不是讀玩家phase13/14/15的同一函式。
- K-SUBAI已存`549145..549150`將CAIControl+70 DWORD、+74 BYTE複製到out，`549155`清CAIControl+72 WORD。因此這條row的第五byte首先來自另一個本地producer，不是自動同玩家當前keyboard方向。
- `548223..54828D`按actor+158->2C、4C9ED0及54F270 gate決定清low15或設定changed；`548290..548318`按actor+158->30、4C9ED0和原候選bit15決定清／重寫bit15。
- 特別是`5482F0..548302`保留low15、把`actor+158->28 << 15`的低16位OR回out+2。它沒有546100的「low15非零直接跳過移動分支」結構。所以546100的`action!=0 ⇒ bit15=0`只限定該callback的受證路徑，**不可提升為所有controller／所有actor row通則**。本段也未證548FF0所有輸出集合，故不反向斷言此時實際wire一定有兩者同時1。
- out+4在候選bit15成立且可移動gates成立時會與已保存E4比較，變化則`5482C8`呼叫actor virtual+58；`54831C..54832F`比較新舊bit15決定changed。這些是產生／過濾本地候選，沒有物理keyboard-held證據。

Empty callback原件`547230 32 C0 C2 08 00`只return false。它是已知明確例外，不應描述成「所有+48都轉546100」。Base無額外wrapper；MissionRoom直指546100；Tutorial無條件tailjmp；Single／Tag有條件tailjmp與清狀態分支；Formation只有slot0轉546100。

## 6. 第三collector 546D50的舊滑鼠推測應撤下

K-T09與早期T10-12將6F3350推測為游標來源，但後續W01已證Mouse/Joypad裝置分離。本次定向讀取證明：

- `546DAD`要求FB8830==0；`546DC2` GetForegroundWindow等於遊戲HWND；之後`546E03 call6F3350(EDI=&axes,push0)`。
- `6F3350`透過`6F1C60(0)`取得軸組；`6F1C60`清輸出3個DWORD，對manager+8..18的五個device，需vtable+2C、+30皆真以及+20返回非null，才把axes各減0x7FFF後加總。
- `CJoypadDevice` vptr C42448，+20=580F10（`lea eax,[ecx+C];ret`）、+2C=6F3960（this+1124）、+30=6F3970（this+1128），此為可供應的原生軸producer。
- `CMouseDevice` vptr C424A4，+20=8DC2F0（return0），不供應這條axes路徑。沒有根據把6F3350叫作GetCursorPos。
- `546E18..546E47`做長度，需嚴格大於float C55CAC=10240；normalize、atan、π/2與π的運算後`4BB450`量化，另加`434740()+40`物件的+20角度量化。回1代表這條軸方向成立；不是方向鍵held。

本結論界線：已知Joypad wrapper可供這條軸路；不聲稱所有未知input subtype都只能是Joypad，也不推斷使用者當時有接手把。對本次0A契約的意義是，546780彙總回值不是物理keyboard-only held。

## 7. 提供主工作整合的正常時序與待測界線

| 情境 | sampled phase及本collector反應 | 不可從此推得 |
|---|---|---|
| direction按下→持續，Z新按 | direction1→2均提供同一方向；Z1可OR1且Single互動edge成立 | 每次Z必一包；bit15等於held |
| direction保持，Z放開 | direction2仍提供方向；Z3本輪不新增bit0 | controller+5C既有bit已清、立即移動 |
| direction放開，Z仍按 | direction3不供方向；Z1/2可OR1；預填heading可能仍等於舊方向 | 從heading辨認方向還按著 |
| direction重新按下，Z仍按 | direction1恢復本次heading；Z2仍可OR1 | wire一定出現新的方向按下edge |
| 只改方向 | mapped新舊方向各自有1/3，八向計算按當次有效狀態 | Server可回復實體按鍵順序 |
| 上+左與Z/X在同一sample存在 | 方向A0+Y與mask可同時形成 | 同時移動及施法已執行 |

本輪不執行相反方向、異常UI、故障、重連等待測。玩家既有敘述只支持一段依序上Z／左Z／下Z／右Z的整體未通過報告，不能補寫四組獨立失敗。新診斷尚無新實測結論，本文全部為靜態有界證據。

**主工作尚需合併的必要證據**：546100/5452C0精確最終row條件及清mask時點；動作低15保持時bit15=0的完整路徑；receive actor E2/E4的執行狀態；action buffer／Server消費時刻。本文未假定Server固定last-key、Z強停、one-pending或0.4秒期限。

## 8. key-combinations.csv 草稿符號與整合條件

`key-combinations.csv`有83資料列、使用者指定的10欄。各列為條件式靜態候選，不是實測紀錄。由Artifact Tool建立矩形資料、回讀exact roundtrip與必要組合存在性檢查；CSV本身不提供視覺樣式、公式或工作簿。

- `Y`為本稿第3節當次角度量化；`H=u8(base+Y)`，`B0`為callback預填的actor+B0。
- `M`為fresh action候選（排除舊mask／其他producer）；`W`為受證callback輸出word。列中的「survives」要求相關low15 gates均保留。普通列同時限定owner+58=0；否則需套主工作的覆寫／fallback規則。
- `A_Guarded`、`A_Room`保留供主工作的精確emit／send條件接合。兩者分開是必要的：FBA7AC==1的MissionRoom跳過54F270，M非零本身不一定設emit。不得把此CSV解成「每個pressed或每個eligible batch都一包」。
- `MoveGate`是主工作546100完整CFG計算出的移動候選判斷，不是keyboard held；本子工作沒有另行發明Server真值。
- Square、MissionRoom、Tutorial、Scenario/Formation slot0四個context各列八方向+Z、左上X、左上ZX、ZC，以及t0..t7方向按住／Z連點／方向釋放／重按／只改方向。另列UI消耗、Single一次清狀態、相反方向靜態待測、同sample順序不可逆、Formation副角色及Type1配置例外。
- confidence中的`static-bounded`指原件有界碼路／來源配置成立，不等同FULL-PASS、實際封包驗收、Server正式技能規則或本次四組獨立失敗。
