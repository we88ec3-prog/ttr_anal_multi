# T10/T11 buffer 與 S2C 狀態分層：子工作證據稿

日期：2026-11-03 UTC。只做原始 BIN 唯讀靜態核對；未執行／附加／修改 Client，未全量重反編譯。本稿供本工作包合併，不改正式 Task 狀態。

## 可直接採用的結論

1. 已證的玩家輸入暫存是 controller `+5C` 的一個 WORD OR 聚合器。它會合併已符合 collector 條件的 bit，保留不了按鍵次數、先後或每次方向。這不是「普攻一個 pending ＋技能一個最新 pending」的證據。root 本輪已重核：送出時間／credit gate 未達時跳過 `545B79` 清零；有進 builder 時即使 N=0 仍清零。因此可跨多 frame 合併原先不同時間的 Z/X；不能稱每 tick 都清或固定 0.4 秒期限。[B-S1、B-S4；本輪 root `5452C0`]
2. actor `+158` 是 actor 內嵌 `+F0` FSM 的 current pointer（FSM `+68`），不是「正在排隊的技能」或動畫檔指標。FSM 25 個註冊 state pointer 是狀態類型表，不是 25 格按鍵 buffer。[B-S7、B-S11；新增 B-N2]
3. `000D` 的 actor motion 提交會先轉 FSM state **13 / `ActorStates::CSkillState`**，再把 packet motion WORD／float 交 main virtual `+68`。相對地，`000C` 的 state byte 直接選 FSM state，state **5 / `CharStates::CAttackedState`** 的 entry 會提交 motion 9。`000D motion9` 與 `000C state5` 不是同一條狀態路徑。[B-S2；新增 B-N2/B-N3]
4. `012A` 的來源已可有界閉合：scene 表 key `0x12A` → `4B1A00` → **明確載入 FBA7A4 controller** virtual `+40` →已核三控制器的 `545E20`。它更新／清除 per-actor skill-key timer map，不是動作排隊通知。[B-S1、B-S5；新增 B-N1]
5. **11/1 P0B 的 000E receiver 類型套錯。** 436C40 保留當前 scene 的 ECX，沒有載入 FBA7A4；拿 Tutorial/Single/Formation controller `+28` 來解讀這次 dispatch 無效。原 scene `CMissionField`/`CTutorial`/`CSquare` 的 `+28` 都是 `4B0640`，Scenario/InfiniteDungeon 是 `4C4920`。W06 的 13-byte result consumer 證據應保留；P0B 的「此路只 cleanup／空 stub」結論不能沿用。[B-S3、B-S6、B-S8/B-S9/B-S13；新增 B-N4]
6. 沒有找到／本輪沒有證明玩家動作 FIFO 容量、普攻 pending 數、最新技能覆寫規則、0.4 秒 expiration、連擊／取消／硬直時間、cast-time SP/MP 扣除或退費時點。現有證據確實有另一套資源檢查和狀態／timer 收包流程；須保留其實際 scope，而非把缺口填成 Server 候選規則。

## 證據／review 狀態

先讀本庫 AGENTS、T10/T11 README 與 task.json、現行 RR inbox（無待辦）、T01 W00–W05 複驗及退回，再用 W04–W07 與 11/1 手續稿定位。`shared/integrations/T01-BULK-20261026-02/review-status.jsonl.gz` 的候選函式狀態仍是 frozen `full_function_semantic_review=not-recorded`；這不否定其後 bounded 稿。T01 W00–W05 的 byte/window 支持仍是 bounded R2，七項退回未因本稿解決；本稿不宣告 FULL-PASS／native_complete。[B-S12]

原件 `Tartaros.bin` SHA256 `9741d1975327b9309d82b52f631165bc410757694d7c183a5eed970a53ebef91`，12,472,320 bytes；PE32 x86，imagebase `400000`；`.text raw=VA−400C00`、`.rdata raw=VA−401A00`。新增 `buffer-s2c-native-audit.json` 保存 22 個有界原件窗口、103 個指令邊界 anchors、43 個 vtable pointer 與 13 個 RTTI 名稱；`make_buffer_audit.py` 重現原件識別、hash、指標及 anchor。窗口 hash 證明相同 bytes，不自動證明整個函式語意已審。

新增證據分組：

| ID | 限定窗口／來源 | 所解決的問題 |
|---|---|---|
| B-N1 | `4ADD50` rooted registration、`4B1A00`、`545E20`、`597B70`；C0FAC4/C0FB1C/C0FA14 `+40` | 012A 的來源、controller forwarding、actor timer map reset |
| B-N2 | `4C7070`、`4CD6F0`、`4CB230`、`4CA060`；C075DC/C07BCC/C078EC/C0799C 等原件指標／RTTI | actor current FSM、state flags、state13/5 與 pending 區分 |
| B-N3 | `4B0130`、`4C8A90`、`4C8DA0`、`4CB870`、`4CBB00`、`4C87D0` | 0C/0D 接收、hurt/skill state entry、motion 提交、沒有 state-local 組合窗 |
| B-N4 | `4C4670`、`4FDA30`、`436C40`；C0705C/C073B4/C073E8/C06FB0/BFD974 指標／RTTI | 000E 實際 receiver 是 scene，修正 P0B |
| B-N5 | `4B3090` 與 `4ADD50` key34；已有 B-S10 | 更新三組資源欄位，不是施放當下扣費 |
| B-N6 | `4CDD40`、`4C8580`、`4CA890`；C07B44/C07554 `+20/+54/+68` | 已收到的 moving state 與目前 FSM／motion 可分離 |

## 1. actor current state、已提交 motion 與 pending 必須分開

### 1.1 pointer 與 transition

`4C7070` 基底建構在 actor `+F0` 內嵌 FSM；`4C70A2 lea eax,[actor+F0]`、`4C70AF call4C9F90`，其 current 在 FSM `+68`，即 actor `+158`。CCharacter `4CD6F0` 先 `4CD71C call4C7070`，再寫 main vptr `C07B44`、F0 vptr `C07BCC`。CActor F0 `C075DC+8` 與 CCharacter F0 `C07BCC+8` 都指 `4CA060`。保留方法的既有來源 B-S11 已有 `4CA060` exit/entry 骨架，本輪將它接到具體 actor/F0 位址。[B-S7/B-S11；B-N2]

`4CA060(index)` 在 index=0x1A 或該 state pointer 為 null 時 false；正常路徑：

- `4CA076` 取 current → `4CA07E` old virtual `+C`（exit）。
- `4CA080` 重取 current，`4CA083` 讀 old state `+8` ID，`4CA08A` 寫 new state `+C` previous-state ID。
- `4CA091` current=new，`4CA099` new virtual `+4`（entry），回 true。

這是同步替換 current、呼叫 exit／entry；沒有 input timestamp／排隊 node／pop-next。state `+C` 是前一 state 的 ID，也不是「下一招」。index 輸入域及全生命週期所有 writer 未全審，不把這個函式的單一 0x1A guard 說成全域邊界驗證。

### 1.2 與 controller gate 有關的 concrete state 預設

`4CB230` 成功建構時 `[state+4]=owner`、`[state+8]=ID`，`+28/+2C/+30/+34` 都設0；派生建構改寫如下。RTTI 名稱來自原件 COL→TypeDescriptor，並非以 motion 編號猜測。

| ID | RTTI／vtable | `+28` | `+2C` | `+30` | `+34` | entry 與界線 |
|---:|---|---:|---:|---:|---:|---|
| 1 | `ActorStates::CWaitState` / C0779C | 1 | 1 | 1 | 0 | B-S7 已有 base ctor；預設閒置狀態，不是技能 pending |
| 2 | `CharStates::CMoveState` / C07984 | 1 | 1 | 1 | 0 | `4CD8D0` ID2，`4CD8DF..4CD8E5` 寫三個1 |
| 5 | `CharStates::CAttackedState` / C0799C | 0 | 1 | 0 | 0 | `4CD945` ID5；`4CD94F` +38=9；`4CD956` +2C=1；entry4CB870 |
| 12 | `CharStates::CForceState` / C079B4 | 0 | 1 | 1 | 0 | `4CD9B7` ID12；`4CD9CC/CF` +30/+2C=1 |
| 13 | `ActorStates::CSkillState` / C078EC | 0 | 0 | 0 | 0 | `4C75EA` ID13；`4C75EF` base state ctor；`4C75F6` vptr；entry4CBB00 |
| 3 | `CharStates::CDeadState` / C079CC | 0 | 0 | 0 | 1 | `4CDA26` ID3；`4CDA36` +34=1 |

這是建構值及已讀 entry 的有界關係，不保證所有 runtime writer 永不改旗標。`546100` 讀 current `+2C/+30` 等 gate，需與 root 本輪完整分支合讀。不能只由「CAttackedState +2C=1」宣稱玩家受到攻擊能立即成功施法；其它 collector、matrix、timer、scene、collision 及 Server gate 仍在。

## 2. S2C 已收到狀態如何回饋控制器與畫面

### 2.1 000C state 與 000D motion 是不同欄位

| app key／row | concrete consumer | 原生效果 | 不可外推 |
|---|---|---|---|
| 000B，2+8N | `4AFE60`，B-S2 | actor ID 查表，row+2 byte→E4／main+58；row+3 bit0→E2.bit15；座標與本地controller+74 correction | 沒有 physical key held／released；不是本次0A的 accept ACK |
| 000C，2+3N | `4B0130` | row `{u16 actor,s8 state}`；`4B01A9 movsx` byte→actor+F0 virtual+8；CCharacter→4CA060 | state不是技能ID、motionID或按鍵編碼 |
| 000D，2+9N | `4B01C0`→`4C8A90` | row `{u16 actor,u8 heading,u16 motion,f32 parameter}`；main+58處理heading；4C8A90固定轉FSM13，然後main+68(motion,float) | float不是已證hit-time；任意motion不保證資源存在、可見、或對應某次0A |
| 0000，2+6N | `4AFAF0`→CCharacter main+2C `4CE7F0` | property4寫actor+3E8，會影響未來SkillMatrix tier路徑 | property4不是已證SP/MP或冷卻 |
| 012A，8+6N／reset | `4B1A00`→controller+40→545E20 | per-actor keyed timer值更新／clear | 不表示cast排隊／成功／取消 |
| 0034，2+18N | `4B3090` | typed resource欄位絕對值同步，見§5 | 不等於收到一筆技能便扣費 |
| 000E，2+13N，在已知scene | 436C40→scene+28→4B0640／4C4920 | outcome／effect/display consumer，W06九分支 | 非單一HP subtraction規則、非必然hurt motion、不是0A完整ACK |
| 000F | `4B19D0`→FBA7A4 controller+3C→545C50 | 部分分支CANNOT_USE_SKILL與提示 | 尚無與某一次0A的nonce/skill/mask的一對一correlation |

`4C8A90` 的全部正常 body：先可能落實 actor D8/DC correction並清兩欄；處理B0／attached rotation後，`4C8B58..69` 無條件走 F0+8(13)，再 `4C8B74` sign-extend傳來motion WORD，`4C8B7E` main+68。CCharacter/CActor main+68 都是 `4C8DA0`：`4C8DAD` 寫actor+38C，attached15C/370存在才call7A6970。**FSM state13、motion38C、attached animation實際播放是三層，不可折成一個 executing flag。**[B-S2；B-N2/B-N3]

`000C state5` 的 concrete entry：`4CB877` owner+418=300；`4CB886` 讀state+38（CCharacter ctor=9），`4CB891` main+68(9,1.0)。這是本輪找到的明確 hurt-state→motion9 路徑。沒有證明原版 Server 對每次 hit 必送0C5，也沒有證明先後0E/0C/0D的配對政策。

### 2.2 本地輸入 gate 不等於畫面移動立即停止

CCharacter main+20指4CDD40，`4CDD49 call4C8580`；`4C85AD call4CA890`。其 actor D4!=1 路徑於 `4CAA63` 僅依 actor E2.bit15 決定沿 E4 的向量提交 main+54位移；speed×`1/[FBA7CC+1360]`，該參數舊T09證據是30。圖資／碰撞與後續position setter仍可阻止實際落位。[B-S10；B-N6]

`000D→4C8A90→CSkillState` 不直接清 actor E2.bit15，CSkillState entry也只寫418。因此「input producer因state gate清0A moving bit」與「actor已收到的moving狀態」必須分開。原件可在資料上同時保有 CSkillState13＋E2 moving=1；不能把 Server 只發0D視為原生保證會停止移動。反過來也不能由這個表示能力宣稱官方技能都允許移動施法。是否允許、何時發0B stop、何時恢復，仍是未證 Server規則及待測時序。

### 2.3 朝向取樣時點

收到0D時，packet自己的heading先進 actor virtual+58（CCharacter=4C8C30），更新B0；4C8A90再讀B0進本次視覺／狀態提交。因此 Client 下行端以**收到的0D heading**為準，不須假定從某個本地排隊鍵取朝向。[B-S2/B-N3]

上行0A第五byte如何由當前方向、actorB0或RowB幾何產生，交 root/keys_direction 的控制器證據。因已證+5C只留WORD，不保存「某次Z/X入列時heading＋timestamp」，不能要求 Server 從此字段重建每次按鍵時朝向。Server選排隊時還是施放時定向，目前不是native已證；須保留每筆實際收到的heading與provenance。

## 3. 012A：來源、overwrite／clear、時間與消費

### 3.1 本輪閉合的來源

`4AE28D mov [eax+954],4B1A00`；`954=4+8*12A`。上層有scene/global/client表scope與可能override的限制，參見B-S9/B-S13。當此scene表路由生效時：

```
key012A -> 4B1A00
4B1A06 mov ecx,[FBA7A4]
4B1A0E mov eax,[vptr+40]
4B1A1A call eax (P,L,key)
```

已核 CSingle C0FAC4+40、CTutorial C0FB1C+40、CFormation C0FA14+40 都是545E20。這是**真的controller forwarding**；與無global-load的436C40不同。

### 3.2 解析及資料更新

`545E2F` P+2 WORD actor ID，從controller+0C起三個12-byte actor slots找actor+4相符；找不到便return。`545E5F` P+4 DWORD≠0時 `545E6F call597B70` 清該actor slot timer tree（其sentinel三連結回self、size=0），不是清某個技能pending queue。

P+4=0時，L≥8，count=floor((L−8)/6)，row `{u16 skillKey, i32 value}`。signed整數除以33（toward zero）得q，逐筆：

| 地址 | store | native語意 |
|---|---|---|
| 545EE0 | entry+C=key | timer map key副本 |
| 545EED | entry+0=q | total-like數值，保留原字面型別 |
| 545EF9 | entry+4=q | remaining counter |
| 545F15 | entry+8=1，僅q≠0 | active-like旗標；q=0路徑**沒有明確清+8** |

同key每列透過54F4E0查找／插入，後到row對+0/+4覆寫；不相同skillKey存入不同map entry。因此 timer map有多key，容量不是「1技能 pending」。不應用其key集合推動作排隊長度。

### 3.3 真正消費端與時間來源

W05已證54F200遍歷tree，entry+4非0就DEC1，0停留0；5452C0三actor slot路徑每次呼叫54F200，直接call於545351。54F270選SkillMatrix格並取得skillKey後檢entry+4==0。[B-S1]

可實作的Client計數模型：`on_5452C0_visit: each remaining_nonzero--`；`on_012A_value: total=remaining=trunc(value/33)`；`on_012A_reset: clear timer map`。這是計數式時間，不是一次收row就預約下個cast。數值33確定；該012A輸入i32的正式單位與Server如何設定／何時開始該值仍未知。舊T09的「移動dt用1/30」不能單獨證明5452C0絕對每33ms呼叫一次；應分開列出已證scheduler以及推定的名目換算。

root已復用T09關於F9423C來自timeGetTime的證據，故**送包clock是ms，不可沿用11/1 P0A整體時間單位未知**；但這不使012A的value或普攻combo窗自動成為同一時間源。

W05另證UI `54F330` snapshot timer，且5CE33A寫entry+8=0、5CE348寫entry+4=0。不能把這個map說成只有Server更新＋時鐘遞減、UI全只讀。精確UI觸發條件仍待定向沿5CE0A7等caller，不能從這兩筆清零推出取消／退款。

## 4. 普攻／技能 buffer、combo 與 interrupt 的證據界線

| 所問項目 | 已證 | 還缺什麼／不可冒用 |
|---|---|---|
| 容量 | controller+5C一個WORD，OR可合併多bits；timer map是keyed counters；FSM是current一個＋25狀態註冊表 | 沒有玩家攻擊FIFO的N；沒有basic1/skill1雙pending容器 |
| 入列／重複 | collector eligible則OR既有WORD；同bit重複不增加計數 | 一次按鍵≠一次Server攻擊，連點數不可回復 |
| 覆寫 | mask聚合是OR；同key timer收到值覆寫counter；FSM轉移覆寫current並保存oldID | 三種不同overwrite不可合稱「最新技能覆蓋前技」 |
| 過期／消費 | aggregate在已證builder清零點清；timer decrement/更新/clear；FSM exit/entry | 沒有已證0.4秒input expiration；清WORD不代表Server已執行 |
| combo窗 | 54F270確有mask3/5/6→矩陣4/5/6；mask7分支先選4 | 這是和弦選格，不是普攻連段允許窗；不能把Send gate、33、300或V500ms當連擊窗 |
| cancel窗 | state gate、0C/0D的同步state替換、motion提交均存在 | 未證動畫frame→可取消窗、取消packet、取消成本返還 |
| 移動中斷 | producer可經motion flags／碰撞改變輸出；0B收包moving與FSM分離 | 不能只由動作bit非0或0D推定強制stop/cancel；官方policy未知 |
| 受擊中斷 | 0C state5 entry可提交motion9；0D先轉state13再提交motion | hit→0C5/0D9時序、無敵/霸體/取消特例、持續多久未證 |
| 自然退出 | SkillState13與AttackedState5的virtual+8均476430 `ret4`，沒有本state update中倒數離開；FSM可被0C等外界轉換 | 未窮盡所有state/motion writer，不能斷言只靠Server才退出或永不自動退出 |
| cost/CD | timer/ResourceA/B/C gate可證；以下§5 | Server扣費、CD開始、refund、cast成功點未證 |

`4CBB03`及`4CB877`把actor+418設300。此欄在4C8580有每次update遞減，在CWaitState4CB2C0中可影響idle motion選擇（既有bulk導航）；**沒有證明它是SkillState13停留期限或combo window**。本工作不拿300除以30硬定10秒動作鎖。

## 5. 資源／SP、MP 檢查與扣除時點

### 5.1 已證檢查只到 SubAI scoped predicate

W05 `549980` 經54AE83呼叫，scope是SubAI條件，不是每次玩家0A的必經路。三個資源like欄位分別 `[actor+3C8]+adjustA`、`[actor+3CC]+adjustB`、`[actor+3D0]+adjustC`，若signed-negative便false（549BB6..549BD6）；再549C0E call54F270檢matrix/timer。**該檢查沒有寫回資源扣除。** `549D54`位於另一函式549C60，不能把它混入549980的同一基本塊。HP/SP/MP正式命名及adjustment的skill-table欄位需要獨立來源；本稿保持ResourceA/B/C。[B-S1]

### 5.2 既有訊息可以補「目前資源」，不能補「何時扣費」

B-S10已定位key0034的4B3090。本輪將相同typed writer回到原件補驗：`4ADF1D [table+1A4]=4B3090`，`1A4=4+8*34h`；L≥2時N=floor((L−2)/18)，row start=P+2+18i。

| row offset | 型別／消費 |
|---:|---|
| +0 | u32 kind，具體1/2/3/4分支 |
| +4 | u16 actor map ID |
| +6 | u32 valueA |
| +10 | u32 valueB，kind1等路徑使用 |
| +14 | u32 valueC |

CCharacter成功dynamic_cast、hero-model record等guards後：

| kind | actor直接writer | local hero-record mirror | 原件store |
|---:|---|---|---|
| 2 | +3BC=valueA、+3C8=valueC | +40/+34（local owner匹配） | 4B3243/4B3249 |
| 3 | +3C0=valueA、+3CC=valueC | +44/+38 | 4B321C/4B3222 |
| 4 | +3C4=valueA、+3D0=valueC | +48/+3C | 4B31F5/4B31FB |

CMonster kind2也有3BC/3C8 stores（4B313C/4B3142）。kind1走main+7C/+80/+78，另有record+54/+58/+50。這是已有ResourceA/B/C的server→client絕對數值同步；沒有每次0A對應的cast ID或cost transaction。收到更新後數值變少只能證更新的先後及差值，不能未配對就稱原版在「入列／起手／命中／完成」某一點扣SP/MP。`0000 property1..3`寫的是3B0/3B4/3B8等不同欄，不能混成這三種資源。[B-S10；B-N5]

### 5.3 對 Server 的可實作邊界

Server可以獨立管理其權威資源／冷卻，依已證格式同步Client，並記錄`resource_before/after`、`cast_policy_version`、`cooldown_start_event`等Server事件。但本工作沒有證明這些事件在原版哪一刻發生；不能在native契約寫「0A收即扣SP」「000D必扣MP」「命中才扣」或「取消refund」。所有候選數值及交易時點需標Server候選，且不影響input adapter對原wire的如實保存。

## 6. 000E receiver 勘誤：P0B 為何不能覆蓋 W06

先復用B-S8 scene dispatch與B-S9/B-S13較晚的分層：4930E0的this是CClient+148，`49312D lea ecx,[this+B8]`落在CClient+200的16-byte dispatcher48AAD0，並非直接scene；default可經494360→global8-byte4FDA30→4B7EC0取current scene→scene+4。不能沿用10/26早稿直接4930E0→Scene的簡寫。

一旦進入scene dispatch：

```
4C467C mov esi,ecx                  ; scene
4C467E mov ebx,[esi+key*8+5EAC]      ; scene table B
4C46C3 mov ecx,esi
4C46C5 call ebx                     ; handler receiver仍scene
```

B缺省時4FDA30同樣用 `[scene+4+key*8]`，`4FDA88 mov ecx,esi;4FDA8A call[handler]`。key14的4ADDEA註冊436C40：

```
436C40 mov eax,[ecx]
436C42 jmp [eax+28]                 ; 不另取controller
```

| 實際scene RTTI | vtable | virtual+28原件target |
|---|---|---|
| Scene::CMissionField | C0705C | 4B0640 |
| Scene::CTutorial | C073E8 | 4B0640 |
| Scene::CSquare | C06FB0 | 4B0640 |
| Scene::CScenarioField | C073B4 | 4C4920 |
| Scene::CInfiniteDungeonField | BFD974 | 4C4920 |

P0B列出的C0FAC4/C0FB1C/C0FA14是真實controller vtable bytes，但**沒有證據把該controller指標送入這個436C40**；其cleanup函式存在並不能回答000E接收。W06的4B0640 13B rows、actor IDs、subtype0..8、effects及row+6條件反號仍有效；仍不得由此宣稱HP扣除／自動hurt一定發生。W06未窮盡的49B0D0→7ABCD0、7AC030、5521D0、7D28E0、6D89C0callee與row+10/+11仍是T12有界缺口，不在這輪為inputbuffer擴大重做。

## 7. 保留的最小缺口與下一個可查範圍

- **玩家pending／連擊／取消時間**：已知+5C aggregate／54F270／actor+158 gate不足以建立FIFO。下一項若要證自然退出，可沿具體actor的F0+8 callers與main+68／附屬7A6970→7A7800完成通知，先查既有T09/T10稿，不重做全體動畫反編譯。
- **012A時鐘**：精確value/33確定；要將q命名成毫秒冷卻，需5452C0排程caller以及012A發值來源／原版trace。時間值保留`raw_value`、`divisor33`、`remaining_visits`，不要把Server候選deadline回填成來源。
- **玩家SP/MP**：SubAI549980三個resource負值判斷不擔保玩家input必檢；下一個必要缺口是具名skill-table adjustments與玩家predicate分支caller。0034只能補目前數值，不能補扣費事件。
- **0F correlation**：545C50的P+2..+6、P+7 enum、P+8 bits需再證；目前可標提示，不標某次cast denied ACK。
- **正常玩法驗收**：本工作沒有新增實測；玩家廣場依序試四方向+Z而無逐組結果，仍不能分成四個獨立fail；v16仍未通過。舊152筆0A只有長度，無法補出rows。此稿補靜態模型，不宣告解除遊玩缺陷。

## 8. 可重用來源表

以下由本輪repo檔案實算Git blob，正文以B-S編號引用。新B-N原件窗口及anchors見同目錄JSON。

| ID | repo 路徑 | Git blob |
|---|---|---|
| B-S1 | `kr-temp-roy/T10/W05-20261031/20261031-182635-chatgpt-web-roy-T10-W05-skillmatrix-resource-timing-T11-handoff.md` | `b3c0f31db311cce06f3a87fcbbf4f938171ce972` |
| B-S2 | `kr-temp-roy/T10/W04-20261031/20261031-172536-chatgpt-web-roy-T10-W04-S2C-receive-actor-motion-native.md` | `8e915daab064177490d5de0b3f193810a5de2f41` |
| B-S3 | `kr-temp-roy/T10/W06-20261031/20261031-184010-chatgpt-web-roy-T10-W06-hit-result-death-T12-boundary.md` | `69189fda3fee408c373738a1c1113f9470b9d640` |
| B-S4 | `kr-temp-roy/T10/W07-20261031/20261031-191217-chatgpt-web-roy-T10-W07-S00-combat-feasibility-handoff.md` | `1bd44222725303783c0e216d7dbe88b829b1aba7` |
| B-S5 | `research/handoffs/s00-web-skill-gap-20261101/20261101-T11-KR-SKILL-012A-GATES-BOUNDARY.md` | `3691a72a7177c5fb91767cc01a4caf030375f304` |
| B-S6 | `research/handoffs/s00-web-skill-gap-20261101/20261101-T10-T11-P0B-KR-000E-VTABLE-VS-000D-MOTION.md` | `02d09ab834d5f5b878a419a3391da76b9b077dc4` |
| B-S7 | `kr-temp-roy/20261026-190148-chatgpt-web-roy-T08-CMonster-inherited-components.md` | `77b8dcf98f0c94bd74ad8f52081bd10fea0eb08f` |
| B-S8 | `kr-temp-roy/20261026-211852-chatgpt-web-roy-T08-dispatch-composite-id.md` | `96061996117565ac35209a4dcd027155703395d6` |
| B-S9 | `kr-temp-roy/20261028-1942-chatgpt-web-roy-T10-106-queue-header-key-and-dispatch-bases.md` | `b9873d454eca75147c3251b85aed7f54929ecb5f` |
| B-S10 | `kr-temp-roy/20261027-141326-claude-web-roy-T09-bulk-tick-rate-hero-driven-by-server-echo-and-actor-id-type.md` | `a7dc14d4dcf9458a0a9a1fdb681012a76071f149` |
| B-S11 | `kr/evidence/622c03c8f35e217e0799ca787b550ebad648b9767cbb2bc8f2c74da71d75a65d.txt` | `b6c49209c9047ed4afec118eafa2a34eb038fcec` |
| B-S12 | `research/handoffs/t01-20261031-t10-w00-w05-native-review/README.md` | `d978ee1e8f090e28bb996d2600b58b020ed81347` |
| B-S13 | `kr-temp-roy/20261029-234329-chatgpt-web-roy-T16-109-KR-quest14-16-15-five-studies-native-receiver-to-Phindous.md` | `d256fd6a32e34eff00ef5d80e57ef088759d338f` |
