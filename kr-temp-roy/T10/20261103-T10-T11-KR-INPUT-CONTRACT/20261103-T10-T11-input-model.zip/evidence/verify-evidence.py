#!/usr/bin/env python3
"""Read-only verification of the KR evidence package, not a semantic FULL-PASS.

Only this verifier is executed. The supplied BIN is read as bytes; no target
code, Client API, process, debugger or game is executed or attached.
Requires pefile and capstone. --repo is optional and reads source files only.
"""
from pathlib import Path
import argparse
import hashlib
import json
import struct
import sys
import pefile
from capstone import Cs, CS_ARCH_X86, CS_MODE_32

TARGET = '9741d1975327b9309d82b52f631165bc410757694d7c183a5eed970a53ebef91'
FILES = ['core-native-audit.json', 'keys-direction-evidence.json',
         'buffer-s2c-native-audit.json', 'wire-complements-provenance.json']

def hx(value):
    return int(str(value), 16)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bin', required=True, type=Path)
    parser.add_argument('--repo', type=Path)
    parser.add_argument('--output', type=Path,
                        help='Optional verification-result JSON output; never the BIN path.')
    args = parser.parse_args()
    evidence = Path(__file__).resolve().parent
    bin_path = args.bin.resolve()
    if args.output and args.output.resolve() == bin_path:
        parser.error('output must not overwrite the evidence BIN')
    data = bin_path.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    assert sha == TARGET, ('target_sha256', sha)
    assert len(data) == 12472320, ('target_size', len(data))
    pe = pefile.PE(data=data, fast_load=False)
    base = pe.OPTIONAL_HEADER.ImageBase
    assert base == 0x400000
    assert pe.FILE_HEADER.Machine == 0x14c
    def raw(va):
        return pe.get_offset_from_rva(va-base)
    def u32(va):
        return struct.unpack_from('<I', data, raw(va))[0]
    def cstr(va):
        offset = raw(va)
        return data[offset:data.index(b'\0', offset)].decode('ascii')

    audits = {name: json.loads((evidence/name).read_text()) for name in FILES}
    md = Cs(CS_ARCH_X86, CS_MODE_32)
    boundaries = {}
    stats = dict(windows=0, anchor_bytes=0, anchor_boundaries=0,
                 raw_offsets=0, vtable_pointers=0, rtti_records=0,
                 constants=0, imports=0, source_blobs=0)
    window_results = []
    for name, audit in audits.items():
        for key in ('target_sha256', 'bin_sha256'):
            if key in audit:
                assert audit[key] == TARGET
        for w in audit.get('windows', []) + audit.get('additional_windows', []):
            start = hx(w.get('va_start', w.get('start_va', w.get('start'))))
            end = hx(w.get('va_end_exclusive', w.get('end_va_exclusive', w.get('end_exclusive'))))
            offset = raw(start)
            chunk = data[offset:raw(end-1)+1]
            assert len(chunk) == end-start, (name, 'noncontiguous', w)
            assert hashlib.sha256(chunk).hexdigest() == w['sha256'], (name, w)
            stored_raw = w.get('raw_start', w.get('raw'))
            if stored_raw is not None:
                assert hx(stored_raw) == offset, (name, w)
                stats['raw_offsets'] += 1
            if 'length' in w:
                assert w['length'] == len(chunk)
            decoded = {i.address for i in md.disasm(chunk, start)}
            boundaries.setdefault(start, set()).update(decoded)
            stats['windows'] += 1
            window_results.append(dict(audit=name, start=f'{start:08X}',
                                       end_exclusive=f'{end:08X}', status='PASS'))
    all_boundaries = set().union(*boundaries.values())
    for name, audit in audits.items():
        for anchor in audit.get('anchors', []):
            va = hx(anchor['va'])
            expected = bytes.fromhex(anchor.get('bytes', anchor.get('hex')))
            offset = raw(va)
            assert data[offset:offset+len(expected)] == expected, (name, anchor)
            if 'raw' in anchor:
                assert hx(anchor['raw']) == offset
                stats['raw_offsets'] += 1
            stats['anchor_bytes'] += 1
            if 'rooted_from' in anchor:
                start = hx(anchor['rooted_from'])
                assert va in boundaries[start], (name, 'not rooted boundary', anchor)
            else:
                assert va in all_boundaries, (name, 'not covered boundary', anchor)
            stats['anchor_boundaries'] += 1
        assert not audit.get('requested_nonboundary_anchors', []), name
        for point in audit.get('pointers', []):
            va = hx(point['va'])
            assert u32(va) == hx(point['target']), (name, point)
            assert raw(va) == hx(point['raw'])
            stats['vtable_pointers'] += 1
        for record in audit.get('rtti', []) + audit.get('controller_vtables', []):
            vt = hx(record.get('vptr', record.get('vtable')))
            col = hx(record.get('COL', record.get('col')))
            td = hx(record.get('type_descriptor', record.get('TypeDescriptor')))
            assert u32(vt-4) == col, (name, record)
            assert u32(col+12) == td, (name, record)
            assert cstr(td+8) == record['name'], (name, record)
            stats['rtti_records'] += 1
            for offset, target in record.get('slots', {}).items():
                assert u32(vt+hx(offset)) == hx(target)
                stats['vtable_pointers'] += 1
        for constant in audit.get('constants', []):
            va = hx(constant['va'])
            fmt = constant['format']
            assert struct.unpack_from(fmt, data, raw(va))[0] == constant['value']
            assert data[raw(va):raw(va)+struct.calcsize(fmt)] == bytes.fromhex(constant['bytes'])
            stats['constants'] += 1
        for imp in audit.get('imports', []):
            found = [(module.dll.decode(), item.name.decode() if item.name else '')
                     for module in pe.DIRECTORY_ENTRY_IMPORT for item in module.imports
                     if item.address == hx(imp['iat_va'])]
            assert found == [(imp['dll'], imp['name'])], (name, imp, found)
            stats['imports'] += 1

    if args.repo:
        repo = args.repo.resolve()
        catalog = json.loads((evidence/'source-catalog.json').read_text())
        for source in catalog['sources']:
            file = repo/source['path']
            content = file.read_bytes()
            git_blob = hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
            assert git_blob == source['blob'], (source['path'], git_blob)
            assert hashlib.sha256(content).hexdigest() == source['sha256']
            stats['source_blobs'] += 1

    result = dict(status='PASS', target_sha256=sha, target_size=len(data),
                  validation_scope='Original bytes, PE offsets, rooted boundaries, pointers, RTTI, and optionally source blobs only; not semantic FULL-PASS or runtime validation.',
                  counts=stats, windows=window_results,
                  target_executed=False, target_modified=False, game_attached=False)
    text = json.dumps(result, ensure_ascii=False, indent=2)+'\n'
    if args.output:
        args.output.write_text(text)
    print(json.dumps({k: result[k] for k in ('status', 'target_sha256', 'counts', 'target_executed', 'target_modified', 'game_attached')}, ensure_ascii=False))

if __name__ == '__main__':
    main()
