# Formation 副角色 callback：第五 byte、seed 與 emit 精確補證

原件 SHA256 `9741d1975327b9309d82b52f631165bc410757694d7c183a5eed970a53ebef91`，唯讀原件 x86 指令。這是 `keys-direction.md` 第5.4節的有界增補。先復用 T10-30／31／26，再核必要 native windows；沒有重研整個 SubAI，也不把 frozen `not-recorded` 升格 FULL-PASS。

既有來源：

- **F30**：`kr-temp-roy/T10/20261027-211146-chatgpt-web-roy-T10-30-subai-actor-state-counter-and-branches.md`，548FF0 dispatch／publication／清欄位。
- **F31**：`kr-temp-roy/T10/20261027-211146-chatgpt-web-roy-T10-31-skill-candidate-fallback-and-matrix-stage.md`，549C60 的 mask 更新與 target-coordinate heading writer。
- **F26**：`kr-temp-roy/T10/20261027-205931-chatgpt-web-roy-T10-26-subai-cast-state-machine.md`，549E10 的 local heading／候選位元；只引用具體writer與分支，不沿用該舊稿對相鄰549D54函式起點的概括。

符號：`C`=Formation controller；`i`=1或2；`R=C.slot[i].actor`；`O`=caller提供5-byte output；`A=FB7A28`（CAIControl）；`W=WORD[O+2]`；`H=BYTE[O+4]`。

## 1. callback進入時沒有把B0／E4寫成O的預設值

| VA | 指令／條件 | 確定效果 |
|---|---|---|
| 5480A3..5480D0 | 有actor，i!=0→5480C1 call5480E0；i==0→5480D0 call546100 | 本補證限Formation副角色；dispatcher不初始化O |
| 548114、54811F..548137 | 取R並檢查null | R不存在返回AL=0，不寫O |
| 548141、54814D | `R+E0 DWORD → local[esp+1C]` | 保存舊5-byte狀態的前4bytes，只供比較 |
| 548147、548151 | `R+E4 BYTE → local[esp+20]` | 保存舊heading，只供後面與新H比較 |
| 548155 | local emit=0 | 不是O初始化 |
| 548189..5481B3 | 傳O給548FF0 | O的首個受證覆寫在548FF0 publish分支 |

**結論：5480E0沒有與546100相同的 `O+2=0; O+4=R+B0` 起始寫入。E4的讀取不能當成O+4初始化。** 在正常548FF0 publish分支，H來自A+74。未走publish時，這兩函式沒有提供可保證的B0／E4預設值；須保留caller輸入／不變量界線，不能直接宣稱遊戲實際發送未初始化資料。

## 2. 548FF0的輸入綁定、seed與採樣時間

5480E0在5481B3呼叫時：EAX=R（副角色）、ECX=C.slot0.actor（主角色）、stack帶A、另一副角色、i-1、O。548FF0在`549003/549009/54900C/54900F/549012`分別寫A+50/+54/+58/+5C/+60。這是**本次callback**的actor指標與slot綁定，沒有物理pressed/released時間或按鍵queue項目。

### 2.1 全域初值和本次保留值不同

`548DA0` ctor在`548E02 xor ecx,ecx`後，`548F07 [FB7A98]=ECX`清A+70 DWORD（包含A+72 WORD），`548F0D [FB7A9C]=CL`清A+74 BYTE。這是AI物件初始化，不是每次548FF0都重新執行。

548FF0入口沒有把本次R+B0或R+E4複製到A+74，也沒有逐次清A+72／+74。正常publish結尾只清A+72，**不清A+74**（第3節）。因此第五byte應描述為「本次AI producer publish時的A+74：由候選helper本次寫入，或在沒有新writer的條件下沿用A的既存值」；不宣稱所有候選策略的完整可達集合均已窮盡。

### 2.2 549180讀主角色B0是算formation目標，不是寫H

`549015 call549180`；後者要求A+54主actor及A+50副actor均存在。`5491A3`讀主actor+B0，`5491CB/5491D1`另讀B0-40，查256方向表；`549212..549281`用主actor的當次A0/A4位置與formation offset計算A+64/+68。整個`549180..549288`沒有A+70/+72/+74或O+4 writer。

所以「本次讀到了B0」不等於「輸出的fifth byte就是B0」。這裡取得的是候選策略稍後使用的當次目標幾何。

### 2.3 既有候選helper可見的兩類heading writer

**549E10（F26，原件重核）**：只有slot state進入2／3處理分支後，`549ED5`讀副角色R+B0作local heading seed。經候選存在與距離／幾何條件：

- 在幾何分支，`549FCC`或`549FE7 call4BB450`量化本次向量角度，寫local heading。
- 在近距分支，`549FF8`讀主actor+B0、`549FFE`寫local heading。
- `54A00F`把AI+72整WORD寫成局部bool<<15；`54A013`把local heading寫A+74。
- state不是2／3時在54A040返回0，不走上述writer。其他失敗／分支若走54A004，也可把seed heading和清bit15結果寫回。

**549C60（F31，原件重核）**：54F270 predicate通過時，`549D5D..549D72`更新A+72的low15並保存原bit15。在後續target非null及result非0條件下，`549D9D..549DB9`取本次target與副actor A0/A4差，`549DE4 call4BB450`量化，`549DEC`寫A+74。

這些是本地候選生成時的幾何取樣／欄位快照；不是排隊時的物理按鍵朝向，也不證Server最終施放時間朝向。其他策略callee只沿F30既有有界dispatch引用，不在本輪窮盡。

## 3. publish不是函式數值回傳，且有不寫O的early return

F30與本次原件相符：548FF0若A+50不存在（54901D/54901F→549168），或R+4 WORD沒有命中A+A8起三個stride16記錄（549025..549044），可直接返回而不寫O。此處的null guard在5480E0正常呼叫前已有R非null檢查；不能把它另稱為已發生的正常runtime失敗。5480E0並沒有檢查一個「548FF0成功」布林回傳；它在call後繼續自身gates。不可把EAX叫作row成功狀態。

達正常publish支路時，順序精確如下：

| VA | 效果 |
|---|---|
| 549145 | 讀DWORD[A+70] |
| 549148、54914B | 取O並寫DWORD[O]=DWORD[A+70]；因此W來自WORD[A+72] |
| 54914D、549150 | 讀BYTE[A+74]，寫BYTE[O+4]；這是H的明確writer |
| 549153、549155 | 清WORD[A+72]=0；保留A+74 |
| 549159..549165 | 清A+50/+54/+58/+5C/+60綁定欄位 |
| 54916E | ret10 |

清A+72是已publish候選的本地消費點；不能命名為Z按鍵queue出列，也沒有expiry deadline含義。O的actor ID最後仍須由5452C0 caller的append規則判斷，勿拿A+70低WORD當最終wire identity契約。

## 4. 5480E0後段：H不再直接覆寫，emit與bit15按以下順序計算

call548FF0之後，5480E0沒有直接O+4 writer。`5482B6`讀H、`5482BA`與進函式時保存的R+E4比較；條件成立時將H作數值傳給actor virtual+58（5482C8），沒有把O pointer作參數。未窮盡該virtual所有alias副作用，但本函式內不存在「再以B0／E4覆寫H」的指令。

| 順序／VA | 條件 | W／emit行為 |
|---|---|---|
| 5481E5..54821D | actor+88 model>9、hero record無效等 | 返回false；此時548FF0可能已寫O，仍不等於append |
| 548223..548246 | R+158不存在、component+2C==0，或4C9ED0!=0 | `W &= 8000`，清low15；emit維持目前值0 |
| 54824C..54828D | 上列action gate通過且W.low15!=0 | call54F270；成功於548288設emit=1；失敗於5482E6 `W &= 8000` |
| 548290..5482A9；548313/548318 | R+158不存在、component+30==0，或4C9ED0!=0 | `W &= 7FFF`清bit15 |
| 5482AB..5482B4；548308/54830D | movement gates通過，但候選bit15==0 | 保持low15，清bit15；不因H不同而設emit |
| 5482B6..5482CA | movement gates通過、候選bit15!=0、H!=保存的E4 | actor virtual+58(H)，emit=1；本函式不重寫H |
| 5482CF..548302 | movement gates通過、候選bit15!=0 | 重新取component+28（null則0）；`W=(W&7FFF) | uint16(component28<<15)`，即由該值bit0寫最終bit15 |
| 54831C..54832F | 最終W.bit15不同於保存的舊E2.bit15 | emit=1；只比較bit15，非整WORD／全部H差異 |
| 548334..54834A | 正常結尾 | return emit；actual row append與transport仍由5452C0處理 |

順序尤其重要：**H差異比較在重寫bit15之前**，且只在進入該段時候選bit15已為1、movement gates通過才做。最後bit15若被component+28改為0，先前的emit=1不會因此撤回。low15被接受也可獨立設emit；沒有546100那條low15非零便略過兩個移動writer的相同CFG。

## 可直接替換主表的一格

> **Formation slot1/2，5480A0→5480E0→548FF0**：callback不以B0／E4初始化O；先保存E0/E4為比較舊值。若548FF0達publish，W與H分別取當時CAIControl+72/+74，之後清CAIControl+72但保留+74。H可由本次候選策略的副／主actor B0或位置幾何生成，非keyboard collector值；沒有新writer時的既存A+74必須與本次取樣區分。5480E0後段不直接覆寫H，只在候選bit15與movement gates成立時與舊E4比較、可呼叫actor v+58，再過bit15重寫及emit判斷。未publish的early-return不提供可保證的fifth-byte seed；caller覆寫／append gate另算。
